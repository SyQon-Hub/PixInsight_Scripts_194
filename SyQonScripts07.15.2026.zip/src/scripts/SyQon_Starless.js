#engine v8

#feature-id SyQonStarless : SyQon > Starless
#feature-icon  syqonstarless.svg
#feature-info This script integrates with the SyQon Starless application to remove stars from images.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/****************************************************************************
 * ███████╗██╗   ██╗ ██████╗  ██████╗ ███╗   ██╗
 * ██╔════╝╚██╗ ██╔╝██╔═══██╗██╔═══██╗████╗  ██║
 * ███████╗ ╚████╔╝ ██║   ██║██║   ██║██╔██╗ ██║
 * ╚════██║  ╚██╔╝  ██║▄▄ ██║██║   ██║██║╚██╗██║
 * ███████║   ██║   ╚██████╔╝╚█████╔╝ ██║ ╚████║
 * ╚══════╝   ╚═╝    ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═══╝
 *      ★  S T A R L E S S  ★
 *
 * SyQon Starless PixInsight Integration
 * Version: v3.0.2
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * Integrates with SyQon Starless (Qt6/C++ build, Axiom V3 ONNX model).
 * Saves the current image as a temporary 32-bit TIFF, launches SyQonStarless
 * with --gui so the user can control stretch settings interactively, then
 * imports the starless result back into PixInsight once the window closes.
 *
 * License context: "pixinsight" (requires a SyQon PixInsight license).
 *
 ******************************************************************************/

#define VERSION "v3.0.2"

// ============================================================================
// Platform helpers
// ============================================================================

let IS_WINDOWS = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows");
let IS_MACOS   = (CoreApplication.platform == "MACOSX"   || CoreApplication.platform == "macOS");
let IS_LINUX   = (CoreApplication.platform == "Linux");

if ( !IS_WINDOWS && !IS_MACOS && !IS_LINUX )
    console.criticalln( "Unsupported platform: " + CoreApplication.platform );

let pathSeparator = IS_WINDOWS ? "\\" : "/";

// ============================================================================
// Temp / config paths
// ============================================================================

let scriptTempDir           = File.systemTempDirectory + pathSeparator + "SyQonStarlessCLI";
let syqonStarlessConfigFile = scriptTempDir + pathSeparator + "syqon_starless_config.csv";

if ( !File.directoryExists( scriptTempDir ) )
    File.createDirectory( scriptTempDir );

// ============================================================================
// Parameters
// ============================================================================

var SyQonStarlessParameters = {
    targetView:            undefined,
    targetViewId:          "",
    starlessExePath:       "",
    overlap:               64,        // per-side Hann blend region; 128 = large overlap mode
    starsOnlyMode:         "Unscreen",
    outputTimeoutMinutes:  20,
    openDialogBox:         true,

    save: function()
    {
        Parameters.set( "targetViewId",          this.targetViewId );
        Parameters.set( "starlessExePath",       this.starlessExePath );
        Parameters.set( "overlap",               this.overlap );
        Parameters.set( "starsOnlyMode",         this.starsOnlyMode );
        Parameters.set( "outputTimeoutMinutes",  this.outputTimeoutMinutes );
        Parameters.set( "openDialogBox",         this.openDialogBox );
        this.savePathToFile();
    },

    load: function()
    {
        if ( Parameters.has( "targetViewId" ) )         this.targetViewId        = Parameters.getString(  "targetViewId" );
        if ( Parameters.has( "starlessExePath" ) )
        {
            let _exe = Parameters.getString( "starlessExePath" );
            this.starlessExePath = (typeof _exe === "string") ? _exe : "";
        }
        if ( Parameters.has( "overlap" ) )              this.overlap             = Parameters.getInteger( "overlap" );
        if ( Parameters.has( "starsOnlyMode" ) )        this.starsOnlyMode       = Parameters.getString(  "starsOnlyMode" );
        if ( Parameters.has( "outputTimeoutMinutes" ) ) this.outputTimeoutMinutes = Parameters.getInteger( "outputTimeoutMinutes" );
        if ( Parameters.has( "openDialogBox" ) )        this.openDialogBox       = Parameters.getBoolean( "openDialogBox" );

        this.loadPathFromFile();

        this.targetView = undefined;
        if ( this.targetViewId && this.targetViewId.length > 0 )
        {
            let w = ImageWindow.windowById( this.targetViewId );
            if ( w && !w.isNull ) this.targetView = w.mainView;
        }

        if ( Parameters.isViewTarget && Parameters.targetView )
        {
            this.targetView   = Parameters.targetView;
            this.targetViewId = Parameters.targetView.id;
        }
    },

    savePathToFile: function()
    {
        try
        {
            let file = new File;
            file.createForWriting( syqonStarlessConfigFile );
            file.outTextLn( String( this.starlessExePath || "" ) );
            file.close();
        }
        catch ( error ) { console.warningln( "Failed to save Starless executable path: " + error.message ); }
    },

    loadPathFromFile: function()
    {
        // On macOS the install path is always fixed -- no need for the
        // user to browse for it.
        if ( IS_MACOS )
        {
            this.starlessExePath = "/Applications/SyQonStarless.app/Contents/MacOS/SyQonStarless";
            return;
        }
        try
        {
            if ( File.exists( syqonStarlessConfigFile ) )
            {
                let lines = File.readLines( syqonStarlessConfigFile );
                if ( lines.length > 0 && (!this.starlessExePath || this.starlessExePath.length == 0) )
                    this.starlessExePath = lines[0].trim();
            }
        }
        catch ( error ) { console.warningln( "Failed to load Starless executable path: " + error.message ); }

        // Windows failsafe: standard installer location when we still have no path.
        if ( IS_WINDOWS && (!this.starlessExePath || this.starlessExePath.length == 0) )
        {
            let defaultWinPath = "C:\\Program Files\\SyQon\\Starless\\SyQonStarless.exe";
            if ( File.exists( defaultWinPath ) )
                this.starlessExePath = defaultWinPath;
        }
    }
};

// ============================================================================
// Utility helpers
// ============================================================================

function resolveWindowFromViewId( viewId )
{
    if ( !viewId || viewId.length == 0 ) return null;
    let w = ImageWindow.windowById( viewId );
    return (w && !w.isNull) ? w : null;
}

function getSelectedWindowFromDialog( dialog )
{
    if ( !dialog ) return null;
    let idx = dialog.imageSelectionDropdown.currentItem;
    if ( idx < 0 || idx >= dialog._windowIds.length ) return null;
    return resolveWindowFromViewId( dialog._windowIds[idx] );
}

function validateStarlessExecutable( exePath )
{
    return exePath && exePath.length > 0 && File.exists( exePath );
}

function sanitizeFileName( name )
{
    return name.replace( /[^A-Za-z0-9_\-]/g, "_" );
}

function deleteFileIfExists( filePath )
{
    try
    {
        if ( File.exists( filePath ) )
        {
            File.remove( filePath );
            console.writeln( "Deleted file: " + filePath );
        }
    }
    catch ( error ) { console.warningln( "Failed to delete file: " + filePath + " -> " + error.message ); }
}

function getActiveWindowIdSafe()
{
    try   { return ImageWindow.activeWindow.mainView.id; }
    catch ( e ) { return ""; }
}

function ensureTempDirExists()
{
    if ( !File.directoryExists( scriptTempDir ) )
        File.createDirectory( scriptTempDir );
}

function buildRunPaths( baseName )
{
    ensureTempDirExists();
    let runTag   = String( (new Date()).getTime() );
    let safeBase = sanitizeFileName( baseName );
    return {
        // Both input and output use TIFF
        inputFilePath:  scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_input.tif",
        outputFilePath: scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_starless.tif",
        starsFilePath:  scriptTempDir + pathSeparator + "starmask_" + safeBase + "_" + runTag + "_starless.tif"
    };
}

function makeUniqueViewId( baseId )
{
    return sanitizeFileName( baseId ) + "_" + String( (new Date()).getTime() );
}

function formatElapsed( ms )
{
    let s = Math.max( 0, Math.floor( ms / 1000 ) );
    let h = Math.floor( s / 3600 ); s -= h * 3600;
    let m = Math.floor( s / 60 );   s -= m * 60;
    return h > 0 ? format( "%d:%02d:%02d", h, m, s ) : format( "%02d:%02d", m, s );
}

// ============================================================================
// Clone / FITS helpers
// ============================================================================

function cloneWindowForProcessing( sourceWindow, newId )
{
    let src = sourceWindow.mainView.image;
    let w   = new ImageWindow(
        src.width, src.height,
        src.numberOfChannels, src.bitsPerSample,
        src.isReal,
        src.isColor, newId );
    w.mainView.beginProcess( UndoFlag.NoSwapFile );
    w.mainView.image.assign( src );
    w.mainView.endProcess();
    return w;
}

function saveImageAsTiff( filePath, view )
{
    let F = new FileFormat( "TIFF", false, true );
    if ( F.isNull )
        throw new Error( "TIFF file format not available." );

    let f = new FileFormatInstance( F );
    if ( f.isNull )
        throw new Error( "Unable to create FileFormatInstance for TIFF." );

    let description = new ImageDescription();
    description.bitsPerSample      = 32;
    description.ieeefpSampleFormat = true;

    if ( !f.create( filePath, "compression=none" ) )
        throw new Error( "Unable to create TIFF file: " + filePath );

    if ( !f.setOptions( description ) )
    {
        f.close();
        throw new Error( "Unable to set 32-bit float options for TIFF." );
    }

    if ( !f.writeImage( view.image ) )
    {
        f.close();
        throw new Error( "Failed to write image to TIFF: " + filePath );
    }

    f.close();
    console.writeln( "Image saved as 32-bit float TIFF: " + filePath );
    return filePath;
}

function openImageFile( filePath, label )
{
    if ( !File.exists( filePath ) )
        throw new Error( label + " file not found: " + filePath );
    let opened = ImageWindow.open( filePath );
    if ( !opened || opened.length < 1 )
        throw new Error( "Failed to open " + label + " image: " + filePath );
    let w = opened[0];
    w.show();
    return w;
}

// ============================================================================
// Output processing
// ============================================================================

function createStarsOnlyImage( originalWindow, starlessWindow, mode )
{
    if ( mode == "None" ) return;

    let originalId = originalWindow.mainView.id;
    let starlessId = starlessWindow.mainView.id;

    let P = new PixelMath;
    P.expression = (mode == "Subtraction")
        ? "(" + originalId + "-" + starlessId + ")"
        : "(" + originalId + "-" + starlessId + ")/(1-" + starlessId + ")";
    P.expression1 = P.expression2 = P.expression3 = "";
    P.useSingleExpression    = true; P.symbols = "";
    P.clearImageCacheAndExit = false; P.cacheGeneratedImages = false;
    P.generateOutput         = true; P.singleThreaded = false; P.optimization = true;
    P.use64BitWorkingImage   = false; P.rescale = false;
    P.truncate               = true; P.truncateLower = 0; P.truncateUpper = 1;
    P.createNewImage         = true; P.showNewImage = true;
    P.newImageId             = originalId + "_StarsOnly";
    P.newImageColorSpace     = PixelMath.SameAsTarget;
    P.newImageSampleFormat   = PixelMath.SameAsTarget;
    P.executeOn( originalWindow.mainView );
}

function overwriteTargetWithStarless( targetWindow, starlessWindow )
{
    let starlessId = starlessWindow.mainView.id;
    if ( !targetWindow.mainView.image.isColor && starlessWindow.mainView.image.isColor )
        starlessId = starlessId + "[0]";

    let pm = new PixelMath;
    pm.useSingleExpression = true;
    pm.expression          = starlessId;
    pm.createNewImage      = false;
    pm.rescale             = false;
    pm.truncate            = false;
    pm.executeOn( targetWindow.mainView );
}

function processStarlessOutput( outputFilePath, targetWindow, starsOnlyMode )
{
    let starlessWindow = openImageFile( outputFilePath, "Starless" );
    try
    {
        if ( starsOnlyMode != "None" )
            createStarsOnlyImage( targetWindow, starlessWindow, starsOnlyMode );
        overwriteTargetWithStarless( targetWindow, starlessWindow );
    }
    finally
    {
        starlessWindow.forceClose();
        deleteFileIfExists( outputFilePath );
    }
}

// ============================================================================
// CLI argument construction
// ============================================================================

function buildStarlessArgs( inputFilePath, outputFilePath )
{
    // Real SyQonStarless.exe CLI contract (Qt6/C++ Axiom V3 build).
    // The old Python starless_cli flags (--pad, --use-mtf, --stars,
    // --channel-mode, --cpu, --no-dml, --json-info, --use-amp etc.)
    // do not exist on this binary -- passing them causes an immediate exit.
    //
    // --gui opens the SyQonStarless window so the user can control
    // stretch settings, device, and tile overlap interactively.
    // The PI script's polling timer watches for the output file to
    // appear after the user closes the window.
    //
    // -t is omitted: the model is statically exported at 512x512, and
    // the app internally ignores any other tile size (clamps to 512).
    let args = [];
    args.push( "-i" ); args.push( inputFilePath  );
    args.push( "-o" ); args.push( outputFilePath );
    args.push( "-v" ); args.push( String( SyQonStarlessParameters.overlap ) );
    args.push( "-c" ); args.push( "pixinsight" );
    args.push( "--gui" );
    return args;
}

// ============================================================================
// executeStarlessOnWindow
// ============================================================================

function executeStarlessOnWindow( targetWindow )
{
    let tempInputFilePath  = "";
    let tempOutputFilePath = "";
    let tempCloneWindow    = null;

    try
    {
        if ( !targetWindow || targetWindow.isNull )
            throw new Error( "No valid target image selected." );
        if ( !validateStarlessExecutable( SyQonStarlessParameters.starlessExePath ) )
            throw new Error( "SyQon Starless executable not found. Please select it with the wrench button." );

        // Resolve macOS .app bundles to the actual binary inside them.
        let resolvedExePath = SyQonStarlessParameters.starlessExePath;

        SyQonStarlessParameters.targetView   = targetWindow.mainView;
        SyQonStarlessParameters.targetViewId = targetWindow.mainView.id;
        SyQonStarlessParameters.save();

        let runPaths = buildRunPaths( targetWindow.mainView.id );
        tempInputFilePath  = runPaths.inputFilePath;
        tempOutputFilePath = runPaths.outputFilePath;

        let cloneId = makeUniqueViewId( targetWindow.mainView.id + "_StarlessTemp" );
        tempCloneWindow = cloneWindowForProcessing( targetWindow, cloneId );
        saveImageAsTiff( tempInputFilePath, tempCloneWindow.mainView );
        tempCloneWindow.forceClose();
        tempCloneWindow = null;

        let args = buildStarlessArgs( tempInputFilePath, tempOutputFilePath );

        let controller = new StarlessRunController( targetWindow, runPaths );

        // Ownership of cleanup transfers to controller
        tempInputFilePath  = "";
        tempOutputFilePath = "";

        controller.start( resolvedExePath, args );
    }
    catch ( error )
    {
        console.criticalln( "SyQon Starless failed: " + error.message );
    }
    finally
    {
        if ( tempCloneWindow && !tempCloneWindow.isNull )
            try { tempCloneWindow.forceClose(); } catch (e) {}
        if ( tempInputFilePath.length  > 0 ) deleteFileIfExists( tempInputFilePath );
        if ( tempOutputFilePath.length > 0 ) deleteFileIfExists( tempOutputFilePath );
    }
}

// ============================================================================
// StarlessRunController
// ============================================================================

var StarlessRunController = class
{
    constructor( targetWindow, runPaths )
    {
        this.targetWindow   = targetWindow;
        this.runPaths       = runPaths;

        this.process        = new ExternalProcess;
        this.waitDialog     = null;
        this.timer          = null;
        this.startTime      = 0;
        this.timeoutMs      = Math.max( 1, SyQonStarlessParameters.outputTimeoutMinutes || 20 ) * 60 * 1000;
        this.canceled       = false;
        this.completed      = false;
        this.cleaned        = false;
        this.stdoutBuffer   = "";
        this.stderrBuffer   = "";
        this.lastStage      = "Waiting for SyQon Starless window to close...";
        this.lastPercent    = -1;
        this.processExited  = false;
    }

    cleanupOnSuccess()
    {
        if ( this.cleaned ) return;
        this.cleaned = true;
        deleteFileIfExists( this.runPaths.inputFilePath );
        // outputFilePath deleted inside processStarlessOutput after load
        deleteFileIfExists( this.runPaths.starsFilePath );
    }

    cleanupOnCancel()
    {
        if ( this.cleaned ) return;
        this.cleaned = true;
        deleteFileIfExists( this.runPaths.inputFilePath );
        // Do NOT delete output/stars -- CLI may still be writing them
    }

    handleLine( line )
    {
        if ( !line ) return;
        let text = line.trim();
        if ( text.length == 0 ) return;

        // Parse [XX%] Progress lines emitted even in --gui mode (the
        // C++ InferenceEngine still writes to stdout while processing)
        let pctMatch = text.match( /\[CLI\]\s+Progress:\s*(\d+)%/i );
        if ( pctMatch )
        {
            this.lastPercent = parseInt( pctMatch[1], 10 );
            this.lastStage   = "Processing tiles...";
            if ( this.waitDialog )
                this.waitDialog.updateStatus( this.lastStage, this.lastPercent, this.startTime, this.timeoutMs );
            return;
        }

        // Parse [CLI] Status: ... stage lines
        let stageMatch = text.match( /\[CLI\]\s+Status:\s*(.+)/i );
        if ( stageMatch )
        {
            this.lastStage = stageMatch[1].trim();
            if ( this.waitDialog )
                this.waitDialog.updateStatus( this.lastStage, this.lastPercent, this.startTime, this.timeoutMs );
            console.noteln( text );
            return;
        }

        // Log everything else but don't update stage
        console.noteln( text );
    }

    processBufferedText( chunk, which )
    {
        if ( !chunk || chunk.length == 0 ) return;
        if ( which == "stdout" ) this.stdoutBuffer += chunk;
        else                     this.stderrBuffer += chunk;

        let buffer    = (which == "stdout") ? this.stdoutBuffer : this.stderrBuffer;
        let lines     = buffer.split( /\r?\n/ );
        let remainder = lines.pop();
        for ( let i = 0; i < lines.length; ++i )
            if ( which == "stdout" ) this.handleLine( lines[i] );
        if ( which == "stdout" ) this.stdoutBuffer = remainder;
        else                     this.stderrBuffer = remainder;
    }

    start( exePath, args )
    {
        this.process.onStandardOutputDataAvailable = () =>
        {
            this.processBufferedText( String( this.process.stdout ), "stdout" );
        };

        this.process.onStandardErrorDataAvailable = () =>
        {
            this.processBufferedText( String( this.process.stderr ), "stderr" );
        };

        this.process.onStarted = () =>
        {
            console.noteln( "SyQon Starless launched." );
            console.noteln( "Executable: " + exePath );
            console.noteln( "Arguments: " + args.join( " " ) );
            this.lastStage = "SyQon Starless window open -- process your image and click Generate Starless.";
            if ( this.waitDialog )
                this.waitDialog.updateStatus( this.lastStage, -1, this.startTime, this.timeoutMs );
        };

        this.process.onFinished = () =>
        {
            // Flush any remaining stdout buffer
            if ( this.stdoutBuffer.length > 0 ) { this.handleLine( this.stdoutBuffer ); this.stdoutBuffer = ""; }
            this.processExited = true;
            console.noteln( "SyQon Starless window closed." );
            this.lastStage = "Window closed -- loading output...";
            if ( this.waitDialog )
                this.waitDialog.updateStatus( this.lastStage, 99, this.startTime, this.timeoutMs );
        };

        this.process.onError = code =>
        {
            console.warningln( "ExternalProcess reported: " + code );
        };

        this.startTime  = (new Date()).getTime();
        this.waitDialog = new StarlessWaitDialog( this );
        this.waitDialog.updateStatus( "Launching SyQon Starless...", -1, this.startTime, this.timeoutMs );

        try { this.process.start( exePath, args ); }
        catch (e) { throw new Error( "Failed to start SyQon Starless: " + e.message ); }

        this._startTimer();
        this.waitDialog.execute();
    }

    _startTimer()
    {
        this.timer          = new Timer;
        this.timer.interval = 0.5;
        this.timer.periodic = true;
        this.timer.onTimeout = () => { this.poll(); };
        this.timer.start();
    }

    _stopTimer()
    {
        try { if ( this.timer ) this.timer.stop(); } catch (e) {}
    }

    poll()
    {
        if ( this.canceled || this.completed ) return;

        let now     = (new Date()).getTime();
        let elapsed = now - this.startTime;

        if ( this.waitDialog )
            this.waitDialog.updateStatus( this.lastStage, this.lastPercent, this.startTime, this.timeoutMs );

        // Only import once the SyQon process has exited AND the output
        // file exists -- prevents PI grabbing the file mid-write while
        // the user is still reviewing inside the SyQon window.
        if ( this.processExited && File.exists( this.runPaths.outputFilePath ) )
        {
            this.completed = true;
            this._stopTimer();

            // Brief wait for file write to complete before opening
            let maxRetries = 10;
            let retryDelay = 2000;
            let lastError  = "";
            let succeeded  = false;

            for ( let attempt = 0; attempt < maxRetries; ++attempt )
            {
                try { msleep( retryDelay ); } catch (e) {}
                try
                {
                    processStarlessOutput(
                        this.runPaths.outputFilePath,
                        this.targetWindow,
                        SyQonStarlessParameters.starsOnlyMode
                    );
                    succeeded = true;
                    break;
                }
                catch (e)
                {
                    lastError = e.message;
                    console.warningln( "Output not ready yet (attempt " + (attempt+1) + "/" + maxRetries + "): " + lastError );
                }
            }

            if ( succeeded )
                console.writeln( "Starless processing complete on: " + this.targetWindow.mainView.id );
            else
                console.criticalln( "SyQon Starless failed while importing output: " + lastError );

            this.cleanupOnSuccess();
            if ( this.waitDialog ) this.waitDialog.ok();
            return;
        }

        // If the process exited but no output file appeared, user
        // probably cancelled inside the SyQon window without processing.
        if ( this.processExited )
        {
            this.completed = true;
            this._stopTimer();
            this.cleanupOnCancel();
            if ( this.waitDialog ) this.waitDialog.cancel();
            console.warningln( "SyQon Starless closed without producing output (cancelled or not processed)." );
            return;
        }

        // Timeout guard
        if ( elapsed >= this.timeoutMs )
        {
            this.completed = true;
            this._stopTimer();
            this.cleanupOnCancel();
            if ( this.waitDialog ) this.waitDialog.cancel();
            console.criticalln( "SyQon Starless timed out -- output file was not produced before timeout." );
            return;
        }
    }

    cancelWaiting()
    {
        if ( this.completed || this.canceled ) return;
        this.canceled = true;
        this._stopTimer();
        this.cleanupOnCancel();
        // Terminate the SyQon process if still running
        try
        {
            if ( this.process && this.process.isRunning )
                this.process.terminate();
        }
        catch (e) {}
        console.warningln( "Cancelled -- SyQon Starless terminated." );
        if ( this.waitDialog ) this.waitDialog.cancel();
    }
};

// ============================================================================
// StarlessWaitDialog
// ============================================================================

var StarlessWaitDialog = class extends Dialog
{
    constructor( controller )
    {
        super();

        this.controller    = controller;
        this.windowTitle   = "SyQon Starless \u2014 Waiting";
        this.userResizable = false;
        this.minWidth      = 560;

        this.waitHeaderLabel = new Label( this );
        this.waitHeaderLabel.useRichText   = true;
        this.waitHeaderLabel.textAlignment = TextAlignment.Center;
        this.waitHeaderLabel.text =
            "<b><font size='+1'>\u2605 SyQon Starless \u2605</font></b><br/>" +
            "<font size='-1'>Waiting for processing to complete...</font>";

        this.headerSep = new Frame( this );
        this.headerSep.frameStyle = FrameStyle.Box;
        this.headerSep.setFixedHeight( 2 );

        this.statusGroup       = new GroupBox( this );
        this.statusGroup.title = "Status";

        this.infoLabel = new Label( this );
        this.infoLabel.useRichText  = true;
        this.infoLabel.wordWrapping = true;
        this.infoLabel.text         = "<i>SyQon Starless window is open. Adjust settings and click Generate Starless, then close the window.</i>";

        this.progressLabel = new Label( this );
        this.progressLabel.useRichText = true;
        this.progressLabel.text        = "<b>Progress:</b> starting...";

        this.progressBarLabel = new Label( this );
        this.progressBarLabel.useRichText = false;
        this.progressBarLabel.text        = "";

        this.elapsedLabel = new Label( this );
        this.elapsedLabel.useRichText = true;
        this.elapsedLabel.text        = "<b>Elapsed:</b> 00:00";

        this.statusGroup.sizer = new VerticalSizer;
        this.statusGroup.sizer.margin = 8; this.statusGroup.sizer.spacing = 6;
        this.statusGroup.sizer.add( this.infoLabel );
        this.statusGroup.sizer.add( this.progressLabel );
        this.statusGroup.sizer.add( this.progressBarLabel );
        this.statusGroup.sizer.add( this.elapsedLabel );

        this.noteLabel = new Label( this );
        this.noteLabel.useRichText  = true;
        this.noteLabel.wordWrapping = true;
        this.noteLabel.text =
            "<i>The SyQon Starless window is running as a separate application.<br/>" +
            "Process your image there, then close that window.<br/>" +
            "Clicking Cancel here will terminate SyQon Starless immediately.</i>";

        this.cancelButton         = new PushButton( this );
        this.cancelButton.text    = "Cancel";
        this.cancelButton.onClick = () => { this.controller.cancelWaiting(); };

        this.buttonSizer = new HorizontalSizer;
        this.buttonSizer.addStretch();
        this.buttonSizer.add( this.cancelButton );
        this.buttonSizer.addStretch();

        this.sizer = new VerticalSizer;
        this.sizer.margin = 12; this.sizer.spacing = 8;
        this.sizer.add( this.waitHeaderLabel );
        this.sizer.add( this.headerSep );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.statusGroup );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.noteLabel );
        this.sizer.addSpacing( 8 );
        this.sizer.add( this.buttonSizer );

        this.adjustToContents();
    }

    updateStatus( stage, percent, startTime, timeoutMs )
    {
        let now     = (new Date()).getTime();
        let elapsed = now - startTime;
        let remain  = Math.max( 0, timeoutMs - elapsed );

        this.progressLabel.text = (percent >= 0)
            ? ("<b>Progress:</b> " + stage + "  [<b>" + percent + "%</b>]")
            : ("<b>Progress:</b> " + stage);

        if ( percent >= 0 )
        {
            let barLen = 40;
            let filled = Math.round( barLen * percent / 100 );
            let bar    = "";
            for ( let i = 0; i < barLen; i++ )
                bar += (i < filled) ? "\u2588" : "\u2591";
            this.progressBarLabel.text = bar + "  " + percent + "%";
        }
        else { this.progressBarLabel.text = ""; }

        this.elapsedLabel.text =
            "<b>Elapsed:</b> " + formatElapsed( elapsed ) +
            "    <b>Timeout in:</b> " + formatElapsed( remain );
    }
};

// ============================================================================
// SyQonStarlessDialog
// ============================================================================

var SyQonStarlessDialog = class extends Dialog
{
    constructor()
    {
        super();

        SyQonStarlessParameters.load();
        this._windowIds = [];

        // ── Header ──
        this.headerLabel = new Label( this );
        this.headerLabel.useRichText   = true;
        this.headerLabel.textAlignment = TextAlignment.Center;
        this.headerLabel.text =
            "<b><font size='+2'>\u2605 SyQon Starless \u2605</font></b><br/>" +
            "<font size='-1'>Axiom V3 \u2014 PixInsight Integration</font>";

        this.headerSeparator = new Frame( this );
        this.headerSeparator.frameStyle = FrameStyle.Box;
        this.headerSeparator.setFixedHeight( 2 );

        // ── Image selection ──
        this.imageSelectionLabel = new Label( this );
        this.imageSelectionLabel.text          = "Target Image:";
        this.imageSelectionLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.imageSelectionDropdown             = new ComboBox( this );
        this.imageSelectionDropdown.editEnabled = false;

        let windows        = ImageWindow.windows;
        let activeWindowId = getActiveWindowIdSafe();
        for ( let i = 0; i < windows.length; ++i )
        {
            let wid = windows[i].mainView.id;
            this.imageSelectionDropdown.addItem( wid );
            this._windowIds.push( wid );
            if ( wid == activeWindowId )
                this.imageSelectionDropdown.currentItem = i;
        }

        this.imageSelectionSizer = new HorizontalSizer; this.imageSelectionSizer.spacing = 4;
        this.imageSelectionSizer.add( this.imageSelectionLabel );
        this.imageSelectionSizer.add( this.imageSelectionDropdown, 100 );

        // ── Overlap ──
        // Tile size is always 512 (fixed by the ONNX static export).
        // The user controls overlap for edge quality vs. speed:
        //   64  = default (stride 384, fastest)
        //   128 = large overlap (stride 256, ~2x tiles, better edges)
        this.overlapLabel = new Label( this );
        this.overlapLabel.text          = "Overlap:";
        this.overlapLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
        this.overlapLabel.toolTip       =
            "Per-side Hann blend region in pixels (tile size is fixed at 512).\n" +
            "64 = default (stride 384). 128 = large overlap (stride 256, ~2x tiles, better edges).";

        this.overlapSpin = new SpinBox( this );
        this.overlapSpin.minValue      = 8;
        this.overlapSpin.maxValue      = 255;  // must be < tileSize/2 to keep stride >= 2
        this.overlapSpin.stepSize      = 8;
        this.overlapSpin.value         = SyQonStarlessParameters.overlap;
        this.overlapSpin.onValueUpdated = v => { SyQonStarlessParameters.overlap = v; };

        this.overlapSizer = new HorizontalSizer; this.overlapSizer.spacing = 4;
        this.overlapSizer.add( this.overlapLabel ); this.overlapSizer.add( this.overlapSpin ); this.overlapSizer.addStretch();

        // ── Stars only mode ──
        this.starsOnlyModeLabel = new Label( this );
        this.starsOnlyModeLabel.text          = "Stars Only:";
        this.starsOnlyModeLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.starsOnlyModeCombo = new ComboBox( this );
        this.starsOnlyModeCombo.addItem( "None" );
        this.starsOnlyModeCombo.addItem( "Subtraction" );
        this.starsOnlyModeCombo.addItem( "Unscreen" );

        let somIndex = 2;
        if      ( SyQonStarlessParameters.starsOnlyMode == "None"        ) somIndex = 0;
        else if ( SyQonStarlessParameters.starsOnlyMode == "Subtraction" ) somIndex = 1;
        else if ( SyQonStarlessParameters.starsOnlyMode == "Unscreen"    ) somIndex = 2;
        this.starsOnlyModeCombo.currentItem    = somIndex;
        SyQonStarlessParameters.starsOnlyMode  = this.starsOnlyModeCombo.itemText( somIndex );
        this.starsOnlyModeCombo.onItemSelected = index =>
        {
            SyQonStarlessParameters.starsOnlyMode = this.starsOnlyModeCombo.itemText( index );
        };

        this.starsOnlyModeSizer = new HorizontalSizer; this.starsOnlyModeSizer.spacing = 4;
        this.starsOnlyModeSizer.add( this.starsOnlyModeLabel );
        this.starsOnlyModeSizer.add( this.starsOnlyModeCombo, 100 );

        // ── Output timeout ──
        this.outputTimeoutLabel = new Label( this );
        this.outputTimeoutLabel.text          = "Output Timeout (min):";
        this.outputTimeoutLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
        this.outputTimeoutLabel.toolTip       = "Maximum time to wait for the Starless output file before aborting.";

        this.outputTimeoutSpin = new SpinBox( this );
        this.outputTimeoutSpin.minValue      = 1;
        this.outputTimeoutSpin.maxValue      = 240;
        this.outputTimeoutSpin.stepSize      = 1;
        this.outputTimeoutSpin.value         = SyQonStarlessParameters.outputTimeoutMinutes;
        this.outputTimeoutSpin.onValueUpdated = v => { SyQonStarlessParameters.outputTimeoutMinutes = v; };

        this.outputTimeoutSizer = new HorizontalSizer; this.outputTimeoutSizer.spacing = 4;
        this.outputTimeoutSizer.add( this.outputTimeoutLabel );
        this.outputTimeoutSizer.add( this.outputTimeoutSpin );
        this.outputTimeoutSizer.addStretch();

        // ── Open dialog checkbox ──
        this.openDialogCheckbox         = new CheckBox( this );
        this.openDialogCheckbox.text    = "Open dialog when instance is double-clicked or dropped";
        this.openDialogCheckbox.checked = SyQonStarlessParameters.openDialogBox;
        this.openDialogCheckbox.onCheck = checked => { SyQonStarlessParameters.openDialogBox = checked; };

        // ── Executable ──
        this.setupButton         = new ToolButton( this );
        this.setupButton.icon    = this.scaledResource( ":/icons/wrench.png" );
        this.setupButton.setScaledFixedSize( 24, 24 );
        this.setupButton.toolTip = "Select the SyQonStarless executable file.";
        this.setupButton.onClick = () =>
        {
            let ofd = new OpenFileDialog;
            ofd.caption            = "Select SyQonStarless Executable";
            ofd.multipleSelections = false;
            if ( SyQonStarlessParameters.starlessExePath.length > 0 )
                ofd.initialPath = SyQonStarlessParameters.starlessExePath;
            ofd.filters = IS_WINDOWS
                ? [ ["Executable Files","*.exe"],["All Files","*"] ]
                : [ ["All Files","*"] ];
            if ( ofd.execute() )
            {
                let picked = "";
                if ( ofd.fileName && ofd.fileName.length > 0 )
                    picked = String( ofd.fileName );
                else if ( ofd.fileNames && ofd.fileNames.length > 0 )
                    picked = String( ofd.fileNames[0] );

                if ( picked.length > 0 )
                {
                    SyQonStarlessParameters.starlessExePath = picked;
                    SyQonStarlessParameters.save();
                    this.exePathLabel.text = picked;
                }
                else
                {
                    console.warningln( "No file was returned from the selection dialog." );
                }
            }
        };

        this.exePathLabel          = new TextBox( this );
        this.exePathLabel.readOnly = true;
        this.exePathLabel.setFixedHeight( 48 );
        this.exePathLabel.text     = SyQonStarlessParameters.starlessExePath.length > 0
            ? SyQonStarlessParameters.starlessExePath
            : "No SyQonStarless executable selected.";

        this.exePathSizer = new HorizontalSizer; this.exePathSizer.spacing = 6;
        this.exePathSizer.add( this.setupButton ); this.exePathSizer.add( this.exePathLabel, 100 );

        // ── Buttons ──
        this.okButton         = new PushButton( this );
        this.okButton.text    = "OK";
        this.okButton.onClick = () => { this.syncToParameters(); this.ok(); };

        this.cancelButton         = new PushButton( this );
        this.cancelButton.text    = "Cancel";
        this.cancelButton.onClick = () => { this.cancel(); };

        this.newInstanceButton = new ToolButton( this );
        this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstanceButton.setScaledFixedSize( 24, 24 );
        this.newInstanceButton.toolTip      = "Drag to workspace to create a new process instance";
        this.newInstanceButton.onMousePress = () => { this.syncToParameters(); this.newInstance(); };

        this.buttonsSizer = new HorizontalSizer; this.buttonsSizer.spacing = 6;
        this.buttonsSizer.add( this.newInstanceButton ); this.buttonsSizer.addStretch();
        this.buttonsSizer.add( this.okButton ); this.buttonsSizer.add( this.cancelButton );

        // ── Label width alignment ──
        let labelWidth = this.font.width( "Output Timeout (min):MMMM" );
        [ this.imageSelectionLabel, this.overlapLabel,
          this.starsOnlyModeLabel, this.outputTimeoutLabel
        ].forEach( lbl => lbl.setFixedWidth( labelWidth ) );

        // ── GroupBoxes ──
        const makeGroup = ( title, ...items ) =>
        {
            let gb   = new GroupBox( this );
            gb.title = title;
            gb.sizer = new VerticalSizer; gb.sizer.margin = 6; gb.sizer.spacing = 4;
            items.forEach( it => gb.sizer.add( it ) );
            return gb;
        };

        this.imageGroup    = makeGroup( "Target Image",        this.imageSelectionSizer );
        this.modelGroup    = makeGroup( "Model Settings (Axiom V3)", this.overlapSizer );
        this.starlessGroup = makeGroup( "Starless Output",     this.starsOnlyModeSizer );
        this.advancedGroup = makeGroup( "Advanced",            this.outputTimeoutSizer, this.openDialogCheckbox );

        this.executableGroup       = new GroupBox( this );
        this.executableGroup.title = "SyQonStarless Executable";
        this.executableGroup.visible = !IS_MACOS;
        this.executableGroup.sizer = new VerticalSizer;
        this.executableGroup.sizer.margin = 6; this.executableGroup.sizer.spacing = 4;
        this.executableGroup.sizer.add( this.exePathSizer );

        let infoLabel = new Label( this );
        infoLabel.useRichText  = true;
        infoLabel.wordWrapping = true;
        infoLabel.text =
            "<i>Stretch settings, device selection, and tile overlap are controlled inside " +
            "the SyQon Starless window. Click <b>Generate Starless</b> there, " +
            "then close the window to return the result to PixInsight.</i>";

        this.copyrightLabel = new Label( this );
        this.copyrightLabel.useRichText   = true;
        this.copyrightLabel.textAlignment = TextAlignment.Center;
        this.copyrightLabel.text =
            "<font size='-1'>\u00A9 SyQon 2026 \u2014 www.syqon.it &nbsp;\u2014&nbsp; " +
            "Script by Franklin Marek \u2014 www.setiastro.com</font>";

        // ── Main sizer ──
        this.sizer = new VerticalSizer; this.sizer.margin = 12; this.sizer.spacing = 8;
        this.sizer.add( this.headerLabel );
        this.sizer.add( this.headerSeparator );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.imageGroup );
        this.sizer.add( this.modelGroup );
        this.sizer.add( this.starlessGroup );
        this.sizer.add( this.advancedGroup );
        this.sizer.add( this.executableGroup );
        this.sizer.addSpacing( 4 );
        this.sizer.add( infoLabel );
        this.sizer.addSpacing( 8 );
        this.sizer.add( this.buttonsSizer );
        this.sizer.addSpacing( 2 );
        this.sizer.add( this.copyrightLabel );

        this.windowTitle = "SyQon Starless " + VERSION;
        this.setMinWidth( 560 );
        this.adjustToContents();

        if ( SyQonStarlessParameters.targetViewId && SyQonStarlessParameters.targetViewId.length > 0 )
            this.selectViewById( SyQonStarlessParameters.targetViewId );
    }

    syncToParameters()
    {
        SyQonStarlessParameters.overlap              = this.overlapSpin.value;
        SyQonStarlessParameters.starsOnlyMode        = this.starsOnlyModeCombo.itemText( this.starsOnlyModeCombo.currentItem );
        SyQonStarlessParameters.outputTimeoutMinutes = this.outputTimeoutSpin.value;
        SyQonStarlessParameters.openDialogBox        = this.openDialogCheckbox.checked;

        let w = getSelectedWindowFromDialog( this );
        if ( w && !w.isNull )
        {
            SyQonStarlessParameters.targetView   = w.mainView;
            SyQonStarlessParameters.targetViewId = w.mainView.id;
        }
        SyQonStarlessParameters.save();
    }

    selectViewById( viewId )
    {
        if ( !viewId || viewId.length == 0 ) return false;
        for ( let i = 0; i < this._windowIds.length; ++i )
            if ( this._windowIds[i] == viewId )
            {
                this.imageSelectionDropdown.currentItem = i;
                return true;
            }
        return false;
    }
};

// ============================================================================
// Main
// ============================================================================

function main()
{
    console.show();
    console.criticalln( " ███████╗██╗   ██╗ ██████╗  ██████╗ ███╗   ██╗" );
    console.criticalln( " ██╔════╝╚██╗ ██╔╝██╔═══██╗██╔═══██╗████╗  ██║" );
    console.criticalln( " ███████╗ ╚████╔╝ ██║   ██║██║   ██║██╔██╗ ██║" );
    console.warningln(  " ╚════██║  ╚██╔╝  ██║▄▄ ██║██║   ██║██║╚██╗██║" );
    console.warningln(  " ███████║   ██║   ╚██████╔╝╚█████╔╝ ██║ ╚████║" );
    console.warningln(  " ╚══════╝   ╚═╝    ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═══╝" );
    console.noteln( "SyQon \u2605 S T A R L E S S \u2605  " + VERSION );
    console.noteln( "\u00A9 SyQon 2026 \u2014 www.syqon.it" );
    console.noteln( "Script by Franklin Marek \u2014 www.setiastro.com" );
    console.flush();

    SyQonStarlessParameters.load();

    if ( Parameters.isGlobalTarget )
    {
        console.criticalln( "This script cannot run in a global context." );
        return;
    }

    if ( Parameters.isViewTarget && Parameters.targetView )
    {
        SyQonStarlessParameters.targetView   = Parameters.targetView;
        SyQonStarlessParameters.targetViewId = Parameters.targetView.id;
        SyQonStarlessParameters.save();

        if ( SyQonStarlessParameters.openDialogBox )
        {
            let dlg = new SyQonStarlessDialog();
            dlg.selectViewById( SyQonStarlessParameters.targetViewId );
            if ( dlg.execute() )
            {
                let selectedWindow = getSelectedWindowFromDialog( dlg )
                    || resolveWindowFromViewId( SyQonStarlessParameters.targetViewId );
                executeStarlessOnWindow( selectedWindow );
            }
            else { console.noteln( "SyQon Starless dialog closed." ); }
            return;
        }

        executeStarlessOnWindow( Parameters.targetView.window );
        return;
    }

    let dlg = new SyQonStarlessDialog();
    if ( dlg.execute() )
    {
        let selectedWindow = getSelectedWindowFromDialog( dlg );
        if ( !selectedWindow && SyQonStarlessParameters.targetViewId.length > 0 )
            selectedWindow = resolveWindowFromViewId( SyQonStarlessParameters.targetViewId );
        if ( !selectedWindow )
            throw new Error( "Please select an image." );
        executeStarlessOnWindow( selectedWindow );
    }
    else { console.noteln( "SyQon Starless dialog closed." ); }
}

main();
