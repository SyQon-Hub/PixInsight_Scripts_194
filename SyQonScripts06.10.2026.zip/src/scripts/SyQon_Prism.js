#engine v8

#feature-id SyQonPrism : SyQon > Prism
#feature-icon  syqonprism.svg
#feature-info This script integrates with the SyQon Prism CLI application to denoise images.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/****************************************************************************
 * ███████╗██╗   ██╗ ██████╗  ██████╗ ███╗   ██╗
 * ██╔════╝╚██╗ ██╔╝██╔═══██╗██╔═══██╗████╗  ██║
 * ███████╗ ╚████╔╝ ██║   ██║██║   ██║██╔██╗ ██║
 * ╚════██║  ╚██╔╝  ██║▄▄ ██║██║   ██║██║╚██╗██║
 * ███████║   ██║   ╚██████╔╝╚██████╔╝██║ ╚████║
 * ╚══════╝   ╚═╝    ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═══╝
 *        ★  P R I S M  ★
 *
 * SyQon Prism CLI PixInsight Integration
 * Version: v1.5
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script integrates with the SyQon Prism CLI application.
 * It saves the current image as a temporary FITS file, runs Prism
 * headlessly with the selected options, and then imports the denoised
 * result back into the target image.
 *
 ******************************************************************************/

#define VERSION "v1.5"

// ============================================================================
// Platform helpers
// ============================================================================

let IS_WINDOWS = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows");
let IS_MACOS   = (CoreApplication.platform == "MACOSX"   || CoreApplication.platform == "macOS");
let IS_LINUX   = (CoreApplication.platform == "Linux");

if ( !IS_WINDOWS && !IS_MACOS && !IS_LINUX )
    console.criticalln( "Unsupported platform: " + CoreApplication.platform );

let pathSeparator = IS_WINDOWS ? "\\" : "/";

// ============================================================================
// Temp / config paths
// ============================================================================

let scriptTempDir        = File.systemTempDirectory + pathSeparator + "SyQonPrismCLI";
let syqonPrismConfigFile = scriptTempDir + pathSeparator + "syqon_prism_config.csv";

if ( !File.directoryExists( scriptTempDir ) )
    File.createDirectory( scriptTempDir );

// ============================================================================
// Parameters
// ============================================================================

var SyQonPrismParameters = {
    targetView:            undefined,
    targetViewId:          "",
    prismExePath:          "",
    modelKind:             "prism_deep",
    tileSize:              512,
    overlap:               128,
    pad:                   512,
    strength:              0.85,
    useMTF:                true,
    mtfTarget:             0.15,
    useAMP:                true,
    ampDType:              "fp16",
    useCPU:                false,
    noDML:                 false,
    outputTimeoutMinutes:  20,
    openDialogBox:         true,

    save: function()
    {
        Parameters.set( "targetViewId",           this.targetViewId );
        Parameters.set( "prismExePath",           this.prismExePath );
        Parameters.set( "modelKind",              this.modelKind );
        Parameters.set( "tileSize",               this.tileSize );
        Parameters.set( "overlap",                this.overlap );
        Parameters.set( "pad",                    this.pad );
        Parameters.set( "strength",               this.strength );
        Parameters.set( "useMTF",                 this.useMTF );
        Parameters.set( "mtfTarget",              this.mtfTarget );
        Parameters.set( "useAMP",                 this.useAMP );
        Parameters.set( "ampDType",               this.ampDType );
        Parameters.set( "useCPU",                 this.useCPU );
        Parameters.set( "noDML",                  this.noDML );
        Parameters.set( "outputTimeoutMinutes",   this.outputTimeoutMinutes );
        Parameters.set( "openDialogBox",          this.openDialogBox );
        this.savePathToFile();
    },

    load: function()
    {
        if ( Parameters.has( "targetViewId" ) )          this.targetViewId         = Parameters.getString(  "targetViewId" );
        if ( Parameters.has( "prismExePath" ) )          this.prismExePath         = Parameters.getString(  "prismExePath" );
        if ( Parameters.has( "modelKind" ) )             this.modelKind            = Parameters.getString(  "modelKind" );
        if ( Parameters.has( "tileSize" ) )              this.tileSize             = Parameters.getInteger( "tileSize" );
        if ( Parameters.has( "overlap" ) )               this.overlap              = Parameters.getInteger( "overlap" );
        if ( Parameters.has( "pad" ) )                   this.pad                  = Parameters.getInteger( "pad" );
        if ( Parameters.has( "strength" ) )              this.strength             = Parameters.getReal(    "strength" );
        if ( Parameters.has( "useMTF" ) )                this.useMTF               = Parameters.getBoolean( "useMTF" );
        if ( Parameters.has( "mtfTarget" ) )             this.mtfTarget            = Parameters.getReal(    "mtfTarget" );
        if ( Parameters.has( "useAMP" ) )                this.useAMP               = Parameters.getBoolean( "useAMP" );
        if ( Parameters.has( "ampDType" ) )              this.ampDType             = Parameters.getString(  "ampDType" );
        if ( Parameters.has( "useCPU" ) )                this.useCPU               = Parameters.getBoolean( "useCPU" );
        if ( Parameters.has( "noDML" ) )                 this.noDML                = Parameters.getBoolean( "noDML" );
        if ( Parameters.has( "outputTimeoutMinutes" ) )  this.outputTimeoutMinutes = Parameters.getInteger( "outputTimeoutMinutes" );
        if ( Parameters.has( "openDialogBox" ) )         this.openDialogBox        = Parameters.getBoolean( "openDialogBox" );

        this.loadPathFromFile();

        this.targetView = undefined;
        if ( this.targetViewId && this.targetViewId.length > 0 )
        {
            let w = ImageWindow.windowById( this.targetViewId );
            if ( w && !w.isNull ) this.targetView = w.mainView;
        }

        if ( Parameters.isViewTarget && Parameters.targetView )
        {
            this.targetView   = Parameters.targetView;
            this.targetViewId = Parameters.targetView.id;
        }
    },

    savePathToFile: function()
    {
        try
        {
            let file = new File;
            file.createForWriting( syqonPrismConfigFile );
            file.outTextLn( this.prismExePath );
            file.close();
        }
        catch ( error ) { console.warningln( "Failed to save Prism executable path: " + error.message ); }
    },

    loadPathFromFile: function()
    {
        try
        {
            if ( File.exists( syqonPrismConfigFile ) )
            {
                let lines = File.readLines( syqonPrismConfigFile );
                if ( lines.length > 0 && (!this.prismExePath || this.prismExePath.length == 0) )
                    this.prismExePath = lines[0].trim();
            }
        }
        catch ( error ) { console.warningln( "Failed to load Prism executable path: " + error.message ); }
    }
};

// ============================================================================
// Utility helpers
// ============================================================================

function resolveWindowFromViewId( viewId )
{
    if ( !viewId || viewId.length == 0 ) return null;
    let w = ImageWindow.windowById( viewId );
    return (w && !w.isNull) ? w : null;
}

function getSelectedWindowFromDialog( dialog )
{
    if ( !dialog ) return null;
    let idx = dialog.imageSelectionDropdown.currentItem;
    if ( idx < 0 || idx >= dialog._windowIds.length ) return null;
    return resolveWindowFromViewId( dialog._windowIds[idx] );
}

function sanitizeFileName( name )
{
    return name.replace( /[^A-Za-z0-9_\-]/g, "_" );
}

function deleteFileIfExists( filePath )
{
    try
    {
        if ( File.exists( filePath ) )
        {
            File.remove( filePath );
            console.writeln( "Deleted file: " + filePath );
        }
    }
    catch ( error ) { console.warningln( "Failed to delete file: " + filePath + " -> " + error.message ); }
}

function getActiveWindowIdSafe()
{
    try   { return ImageWindow.activeWindow.mainView.id; }
    catch ( e ) { return ""; }
}

function ensureTempDirExists()
{
    if ( !File.directoryExists( scriptTempDir ) )
        File.createDirectory( scriptTempDir );
}

function buildRunPaths( baseName )
{
    ensureTempDirExists();
    let runTag   = String( (new Date()).getTime() );
    let safeBase = sanitizeFileName( baseName );
    return {
        inputFilePath:  scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_input.fits",
        outputFilePath: scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_prism.fits",
        jsonInfoPath:   scriptTempDir + pathSeparator + safeBase + "_" + runTag + "_prism.json"
    };
}

function makeUniqueViewId( baseId )
{
    return sanitizeFileName( baseId ) + "_" + String( (new Date()).getTime() );
}

// ============================================================================
// PI-side temp stretch / destretch helpers
// ============================================================================

function cloneWindowForProcessing( sourceWindow, newId )
{
    let src = sourceWindow.mainView.image;
    let w   = new ImageWindow(
        src.width, src.height,
        src.numberOfChannels, src.bitsPerSample,
        src.isReal,   // replaces SampleType_Real comparison
        src.isColor, newId );
    w.mainView.beginProcess( UndoFlag.NoSwapFile );
    w.mainView.image.assign( src );
    w.mainView.endProcess();
    return w;
}

function applyPixelMathToView( view, expr, symbols )
{
    let pm = new PixelMath;
    pm.useSingleExpression  = true;
    pm.expression           = expr;
    pm.symbols              = symbols || "";
    pm.clearImageCacheAndExit = false; pm.cacheGeneratedImages = false;
    pm.generateOutput = true; pm.singleThreaded = false; pm.optimization = true;
    pm.use64BitWorkingImage = true; pm.rescale = false;
    pm.rescaleLower = 0; pm.rescaleUpper = 1;
    pm.truncate = true; pm.truncateLower = 0; pm.truncateUpper = 1;
    pm.createNewImage = false; pm.showNewImage = false;
    pm.newImageId = ""; pm.newImageWidth = 0; pm.newImageHeight = 0; pm.newImageAlpha = false;
    pm.newImageColorSpace   = PixelMath.SameAsTarget;
    pm.newImageSampleFormat = PixelMath.SameAsTarget;
    pm.executeOn( view );
}

function computeAverageMedianScalar( img )
{
    if ( !img.isColor ) return img.median();
    return (img.median( new Rect(0,0,img.width,img.height), 0, 0 ) +
            img.median( new Rect(0,0,img.width,img.height), 1, 1 ) +
            img.median( new Rect(0,0,img.width,img.height), 2, 2 )) / 3;
}

function createPIStretchedTempWindow( sourceWindow, targetMedian )
{
    let tempId     = makeUniqueViewId( sourceWindow.mainView.id + "_PrismTemp" );
    let tempWindow = cloneWindowForProcessing( sourceWindow, tempId );
    let img        = tempWindow.mainView.image;

    let stretchInfo = {
        used: true, targetMedian: targetMedian,
        originalMin: 0, originalMedian: 0, wasColor: img.isColor
    };

    stretchInfo.originalMin = img.minimum();

    // Step 1: blackpoint normalize (single expression works for both mono and color)
    applyPixelMathToView( tempWindow.mainView,
        "BlackPoint=" + format("%.16f", stretchInfo.originalMin) + ";\n" +
        "($T-BlackPoint)/(1-BlackPoint)", "BlackPoint" );

    stretchInfo.originalMedian = computeAverageMedianScalar( tempWindow.mainView.image );

    if ( !isFinite(stretchInfo.originalMedian) || stretchInfo.originalMedian <= 0 || stretchInfo.originalMedian >= 1 )
        throw new Error( "Invalid normalized median for PI temp stretch: " + stretchInfo.originalMedian );

    let om = format( "%.16f", stretchInfo.originalMedian );
    let tm = format( "%.16f", targetMedian );

    // Step 2: median transfer stretch
    applyPixelMathToView( tempWindow.mainView,
        "((" + om + "-1)*" + tm + "*$T)/(" + om + "*(" + tm + "+$T-1)-" + tm + "*$T)", "" );

    return { tempWindow: tempWindow, stretchInfo: stretchInfo };
}

function reversePIStretchOnWindow( prismWindow, stretchInfo )
{
    if ( !stretchInfo || !stretchInfo.used ) return;

    let om = format( "%.16f", stretchInfo.originalMedian );
    let tm = format( "%.16f", stretchInfo.targetMedian );
    let mn = format( "%.16f", stretchInfo.originalMin );

    applyPixelMathToView( prismWindow.mainView,
        "(" + om + "*$T*(" + tm + "-1))/(" +
        om + "*" + tm + " - " + om + "*$T + " + tm + "*$T - " + tm + ")", "" );

    applyPixelMathToView( prismWindow.mainView,
        "($T*(1-" + mn + ")+" + mn + ")", "" );
}

// ============================================================================
// Executable / FITS helpers
// ============================================================================

function validatePrismExecutable( exePath )
{
    return exePath && exePath.length > 0 && File.exists( exePath );
}

function saveImageAsFits( filePath, view )
{
    let imgWindow = view.isMainView ? view.window : view.mainView.window;
    if ( !imgWindow ) throw new Error( "Image window is undefined for the specified view." );
    if ( !imgWindow.saveAs( filePath, false, false, false, false ) )
        throw new Error( "Failed to save image as FITS: " + filePath );
    console.writeln( "Image saved as FITS: " + filePath );
    return filePath;
}

function prismReferenceExpression( targetView, prismWindow )
{
    if ( !targetView.image.isColor && prismWindow.mainView.image.isColor )
        return prismWindow.mainView.id + "[0]";
    return prismWindow.mainView.id;
}

function openPrismOutput( outputFilePath )
{
    if ( !File.exists( outputFilePath ) )
        throw new Error( "Prism output file not found: " + outputFilePath );
    let opened = ImageWindow.open( outputFilePath );
    if ( !opened || opened.length < 1 )
        throw new Error( "Failed to open Prism output image: " + outputFilePath );
    let outWindow = opened[0];
    outWindow.show();
    return outWindow;
}

function overwriteTargetWithPrism( targetWindow, prismWindow )
{
    let expr = prismReferenceExpression( targetWindow.mainView, prismWindow );
    let pm   = new PixelMath;
    pm.useSingleExpression = true;
    pm.createNewImage = false; pm.rescale = false; pm.truncate = false;
    pm.expression = expr;
    pm.executeOn( targetWindow.mainView );
}

function processPrismOutput( outputFilePath, targetWindow, stretchInfo )
{
    let prismWindow = openPrismOutput( outputFilePath );
    try
    {
        if ( stretchInfo && stretchInfo.used )
        {
            console.noteln( "Reversing PI temporary stretch on Prism output..." );
            reversePIStretchOnWindow( prismWindow, stretchInfo );
        }
        overwriteTargetWithPrism( targetWindow, prismWindow );
    }
    finally
    {
        prismWindow.forceClose();
        deleteFileIfExists( outputFilePath );
    }
}

// ============================================================================
// CLI argument construction
// ============================================================================

function buildPrismArgs( inputFilePath, outputFilePath, jsonInfoPath )
{
    let args = [];
    args.push( "--input"  ); args.push( inputFilePath );
    args.push( "--output" ); args.push( outputFilePath );
    args.push( "--model-kind" ); args.push( SyQonPrismParameters.modelKind );
    args.push( "--tile"    ); args.push( String( SyQonPrismParameters.tileSize ) );
    args.push( "--overlap" ); args.push( String( SyQonPrismParameters.overlap ) );
    args.push( "--pad"     ); args.push( String( SyQonPrismParameters.pad ) );
    args.push( "--strength"); args.push( format( "%.2f", SyQonPrismParameters.strength ) );
    if ( SyQonPrismParameters.useAMP ) args.push( "--use-amp" );
    args.push( "--amp-dtype" ); args.push( SyQonPrismParameters.ampDType );
    if ( SyQonPrismParameters.useCPU ) args.push( "--cpu" );
    if ( SyQonPrismParameters.noDML  ) args.push( "--no-dml" );
    if ( jsonInfoPath && jsonInfoPath.length > 0 )
    {
        args.push( "--json-info" ); args.push( jsonInfoPath );
    }
    return args;
}

// ============================================================================
// executePrismOnWindow
// ============================================================================

function executePrismOnWindow( targetWindow )
{
    let tempInputFilePath  = "";
    let tempOutputFilePath = "";
    let tempJsonInfoPath   = "";
    let tempStretchWindow  = null;
    let stretchInfo        = { used: false };

    try
    {
        if ( !targetWindow || targetWindow.isNull )
            throw new Error( "No valid target image selected." );
        if ( SyQonPrismParameters.overlap >= SyQonPrismParameters.tileSize )
            throw new Error( "Overlap must be smaller than tile size." );
        if ( SyQonPrismParameters.prismExePath.length == 0 )
            throw new Error( "Please select the Prism executable with the wrench button." );
        if ( !validatePrismExecutable( SyQonPrismParameters.prismExePath ) )
            throw new Error( "Selected Prism executable does not exist." );

        SyQonPrismParameters.targetView   = targetWindow.mainView;
        SyQonPrismParameters.targetViewId = targetWindow.mainView.id;
        SyQonPrismParameters.save();

        let runPaths = buildRunPaths( targetWindow.mainView.id );
        tempInputFilePath  = runPaths.inputFilePath;
        tempOutputFilePath = runPaths.outputFilePath;
        tempJsonInfoPath   = runPaths.jsonInfoPath;

        let sourceForSaveWindow = targetWindow;

        if ( SyQonPrismParameters.useMTF )
        {
            console.noteln( "Creating PI-side temporary stretch copy..." );
            let stretched = createPIStretchedTempWindow( targetWindow, SyQonPrismParameters.mtfTarget );
            tempStretchWindow   = stretched.tempWindow;
            stretchInfo         = stretched.stretchInfo;
            sourceForSaveWindow = tempStretchWindow;
        }

        saveImageAsFits( tempInputFilePath, sourceForSaveWindow.mainView );

        let args = buildPrismArgs( tempInputFilePath, tempOutputFilePath, tempJsonInfoPath );

        let controller = new PrismRunController( targetWindow, tempStretchWindow, stretchInfo, runPaths );

        // Ownership transfers to controller
        tempStretchWindow  = null;
        tempInputFilePath  = "";
        tempOutputFilePath = "";
        tempJsonInfoPath   = "";

        controller.start( SyQonPrismParameters.prismExePath, args );
    }
    catch ( error )
    {
        console.criticalln( "SyQon Prism CLI failed: " + error.message );
    }
    finally
    {
        if ( tempStretchWindow && !tempStretchWindow.isNull )
            try { tempStretchWindow.forceClose(); } catch (e) {}
        if ( tempInputFilePath.length  > 0 ) deleteFileIfExists( tempInputFilePath );
        if ( tempOutputFilePath.length > 0 ) deleteFileIfExists( tempOutputFilePath );
        if ( tempJsonInfoPath.length   > 0 ) deleteFileIfExists( tempJsonInfoPath );
    }
}

// ============================================================================
// PrismRunController
// ============================================================================

var PrismRunController = class
{
    constructor( targetWindow, tempStretchWindow, stretchInfo, runPaths )
    {
        this.targetWindow      = targetWindow;
        this.tempStretchWindow = tempStretchWindow;
        this.stretchInfo       = stretchInfo;
        this.runPaths          = runPaths;

        this.process      = new ExternalProcess;
        this.waitDialog   = null;
        this.timer        = null;
        this.startTime    = 0;
        this.timeoutMs    = Math.max( 1, SyQonPrismParameters.outputTimeoutMinutes || 20 ) * 60 * 1000;
        this.canceled     = false;
        this.completed    = false;
        this.cleaned      = false;
        this.stdoutBuffer = "";
        this.stderrBuffer = "";
        this.lastStage    = "Starting Prism CLI...";
        this.lastPercent  = -1;
    }

    cleanupOnSuccess()
    {
        if ( this.cleaned ) return;
        this.cleaned = true;
        try { if ( this.tempStretchWindow && !this.tempStretchWindow.isNull ) this.tempStretchWindow.forceClose(); } catch (e) {}
        deleteFileIfExists( this.runPaths.inputFilePath );
        deleteFileIfExists( this.runPaths.outputFilePath );
        deleteFileIfExists( this.runPaths.jsonInfoPath );
    }

    cleanupOnCancel()
    {
        if ( this.cleaned ) return;
        this.cleaned = true;
        try { if ( this.tempStretchWindow && !this.tempStretchWindow.isNull ) this.tempStretchWindow.forceClose(); } catch (e) {}
        // Do NOT delete output/input/json — prism_cli may still be writing them
    }

    handlePrismLine( line, isErrorStream )
    {
        if ( !line ) return;
        let text = line.trim();
        if ( text.length == 0 ) return;

        let tileMatch = text.match( /^\[\s*(\d+)%\]\s+(.*?)\s+\((\d+)\/(\d+)\)$/ );
        if ( tileMatch )
        {
            this.lastPercent = parseInt( tileMatch[1], 10 );
            this.lastStage   = tileMatch[2] + " (" + tileMatch[3] + "/" + tileMatch[4] + ")";
            if ( this.waitDialog )
                this.waitDialog.updateStatus( this.lastStage, this.lastPercent, this.startTime, this.timeoutMs );
            return;
        }

        this.lastStage = text;
        if ( this.waitDialog )
            this.waitDialog.updateStatus( this.lastStage, this.lastPercent, this.startTime, this.timeoutMs );
        console.noteln( text );
    }

    processBufferedText( chunk, isErrorStream, which )
    {
        if ( !chunk || chunk.length == 0 ) return;
        if ( which == "stdout" ) this.stdoutBuffer += chunk;
        else                     this.stderrBuffer += chunk;

        let buffer    = (which == "stdout") ? this.stdoutBuffer : this.stderrBuffer;
        let lines     = buffer.split( /\r?\n/ );
        let remainder = lines.pop();
        for ( let i = 0; i < lines.length; ++i )
            this.handlePrismLine( lines[i], isErrorStream );
        if ( which == "stdout" ) this.stdoutBuffer = remainder;
        else                     this.stderrBuffer = remainder;
    }

    start( exePath, args )
    {
        this.process.onStandardOutputDataAvailable = () =>
        {
            this.processBufferedText( String( this.process.stdout ), false, "stdout" );
        };

        this.process.onStandardErrorDataAvailable = () =>
        {
            this.processBufferedText( String( this.process.stderr ), true, "stderr" );
        };

        this.process.onStarted = () =>
        {
            console.noteln( "Starting Prism CLI..." );
            console.noteln( "Executable: " + exePath );
            console.noteln( "Arguments: " + args.join( " " ) );
            this.lastStage = "Prism CLI started...";
            if ( this.waitDialog )
                this.waitDialog.updateStatus( this.lastStage, this.lastPercent, this.startTime, this.timeoutMs );
        };

        this.process.onFinished = () =>
        {
            if ( this.stdoutBuffer.length > 0 ) { this.handlePrismLine( this.stdoutBuffer, false ); this.stdoutBuffer = ""; }
            if ( this.stderrBuffer.length > 0 ) { this.handlePrismLine( this.stderrBuffer, true  ); this.stderrBuffer = ""; }
            console.noteln( "Prism CLI finished." );
        };

        this.process.onError = code =>
        {
            console.warningln( "ExternalProcess reported: " + code + " (continuing to wait for output)" );
        };

        this.startTime  = (new Date()).getTime();
        this.waitDialog = new PrismWaitDialog( this );
        this.waitDialog.updateStatus( "Launching Prism CLI...", -1, this.startTime, this.timeoutMs );

        try { this.process.start( exePath, args ); }
        catch (e) { throw new Error( "Failed to start Prism CLI: " + e.message ); }

        this._startTimer();
        this.waitDialog.execute();
    }

    _startTimer()
    {
        this.timer          = new Timer;
        this.timer.interval = 0.5;
        this.timer.periodic = true;
        this.timer.onTimeout = () => { this.poll(); };
        this.timer.start();
    }

    _stopTimer()
    {
        try { if ( this.timer ) this.timer.stop(); } catch (e) {}
    }

    poll()
    {
        if ( this.canceled || this.completed ) return;

        let now     = (new Date()).getTime();
        let elapsed = now - this.startTime;

        if ( this.waitDialog )
            this.waitDialog.updateStatus( this.lastStage, this.lastPercent, this.startTime, this.timeoutMs );

        if ( File.exists( this.runPaths.outputFilePath ) )
        {
            this.completed = true;
            this._stopTimer();
            try { msleep( 1000 ); } catch (e) {}
            try
            {
                processPrismOutput( this.runPaths.outputFilePath, this.targetWindow, this.stretchInfo );
                if ( File.exists( this.runPaths.jsonInfoPath ) )
                    console.noteln( "Prism info JSON saved: " + this.runPaths.jsonInfoPath );
                console.writeln( "Prism processing complete on: " + this.targetWindow.mainView.id );
            }
            catch (e) { console.criticalln( "SyQon Prism CLI failed while importing output: " + e.message ); }
            finally
            {
                this.cleanupOnSuccess();
                if ( this.waitDialog ) this.waitDialog.ok();
            }
            return;
        }

        if ( elapsed >= this.timeoutMs )
        {
            this.completed = true;
            this._stopTimer();
            this.cleanupOnCancel();
            if ( this.waitDialog ) this.waitDialog.cancel();
            console.criticalln( "SyQon Prism CLI failed: Prism output file was not found before timeout." );
            return;
        }
    }

    cancelWaiting()
    {
        if ( this.completed || this.canceled ) return;
        this.canceled = true;
        this._stopTimer();
        this.cleanupOnCancel();
        console.warningln( "User canceled waiting for Prism output. Prism CLI may still be running in the background." );
        if ( this.waitDialog ) this.waitDialog.cancel();
    }
};

// ============================================================================
// formatElapsed helper
// ============================================================================

function formatElapsed( ms )
{
    let s = Math.max( 0, Math.floor( ms / 1000 ) );
    let h = Math.floor( s / 3600 ); s -= h * 3600;
    let m = Math.floor( s / 60 );   s -= m * 60;
    return h > 0 ? format( "%d:%02d:%02d", h, m, s ) : format( "%02d:%02d", m, s );
}

// ============================================================================
// PrismWaitDialog
// ============================================================================

var PrismWaitDialog = class extends Dialog
{
    constructor( controller )
    {
        super();

        this.controller    = controller;
        this.windowTitle   = "SyQon Prism \u2014 Processing";
        this.userResizable = false;
        this.minWidth      = 560;

        this.waitHeaderLabel = new Label( this );
        this.waitHeaderLabel.useRichText   = true;
        this.waitHeaderLabel.textAlignment = TextAlignment.Center;
        this.waitHeaderLabel.text =
            "<b><font size='+1'>\u2605 SyQon Prism \u2605</font></b><br/>" +
            "<font size='-1'>Processing in progress...</font>";

        this.headerSep = new Frame( this );
        this.headerSep.frameStyle = FrameStyle.Box;
        this.headerSep.setFixedHeight( 2 );

        this.statusGroup       = new GroupBox( this );
        this.statusGroup.title = "Status";

        this.infoLabel = new Label( this );
        this.infoLabel.useRichText  = true;
        this.infoLabel.wordWrapping = true;
        this.infoLabel.text         = "<i>Waiting for Prism output...</i>";

        this.progressLabel = new Label( this );
        this.progressLabel.useRichText = true;
        this.progressLabel.text        = "<b>Progress:</b> starting...";

        this.progressBarLabel = new Label( this );
        this.progressBarLabel.useRichText = false;
        this.progressBarLabel.text        = "";

        this.elapsedLabel = new Label( this );
        this.elapsedLabel.useRichText = true;
        this.elapsedLabel.text        = "<b>Elapsed:</b> 00:00";

        this.statusGroup.sizer = new VerticalSizer;
        this.statusGroup.sizer.margin = 8; this.statusGroup.sizer.spacing = 6;
        this.statusGroup.sizer.add( this.infoLabel );
        this.statusGroup.sizer.add( this.progressLabel );
        this.statusGroup.sizer.add( this.progressBarLabel );
        this.statusGroup.sizer.add( this.elapsedLabel );

        this.noteLabel = new Label( this );
        this.noteLabel.useRichText  = true;
        this.noteLabel.wordWrapping = true;
        this.noteLabel.text =
            "<i>Cancel stops waiting and closes this script.<br/>" +
            "It does not terminate prism_cli if it is already running.</i>";

        this.cancelButton         = new PushButton( this );
        this.cancelButton.text    = "Cancel";
        this.cancelButton.onClick = () => { this.controller.cancelWaiting(); };

        this.buttonSizer = new HorizontalSizer;
        this.buttonSizer.addStretch();
        this.buttonSizer.add( this.cancelButton );
        this.buttonSizer.addStretch();

        this.sizer = new VerticalSizer;
        this.sizer.margin = 12; this.sizer.spacing = 8;
        this.sizer.add( this.waitHeaderLabel );
        this.sizer.add( this.headerSep );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.statusGroup );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.noteLabel );
        this.sizer.addSpacing( 8 );
        this.sizer.add( this.buttonSizer );

        this.adjustToContents();
    }

    updateStatus( stage, percent, startTime, timeoutMs )
    {
        let now     = (new Date()).getTime();
        let elapsed = now - startTime;
        let remain  = Math.max( 0, timeoutMs - elapsed );

        this.infoLabel.text = "<i>Prism is running...</i>";
        this.progressLabel.text = (percent >= 0)
            ? ("<b>Progress:</b> " + stage + "  [<b>" + percent + "%</b>]")
            : ("<b>Progress:</b> " + stage);

        if ( percent >= 0 )
        {
            let barLen = 40;
            let filled = Math.round( barLen * percent / 100 );
            let bar    = "";
            for ( let i = 0; i < barLen; i++ )
                bar += (i < filled) ? "\u2588" : "\u2591";
            this.progressBarLabel.text = bar + "  " + percent + "%";
        }
        else { this.progressBarLabel.text = ""; }

        this.elapsedLabel.text =
            "<b>Elapsed:</b> " + formatElapsed( elapsed ) +
            "    <b>Timeout in:</b> " + formatElapsed( remain );
    }
};

// ============================================================================
// SyQonPrismDialog
// ============================================================================

var SyQonPrismDialog = class extends Dialog
{
    constructor()
    {
        super();

        SyQonPrismParameters.load();
        this._windowIds = [];

        // ── Header ──
        this.headerLabel = new Label( this );
        this.headerLabel.useRichText   = true;
        this.headerLabel.textAlignment = TextAlignment.Center;
        this.headerLabel.text =
            "<p style='margin-bottom:2px;'>" +
            "<b><font size='+2'>\u2605 SyQon Prism \u2605</font></b><br/>" +
            "<font size='-1'>AI Denoising for PixInsight</font><br/>" +
            "<b>" + VERSION + "</b></p>";

        this.headerSeparator = new Frame( this );
        this.headerSeparator.frameStyle = FrameStyle.Box;
        this.headerSeparator.setFixedHeight( 2 );

        // ── Image selection ──
        this.imageSelectionLabel = new Label( this );
        this.imageSelectionLabel.text          = "Select Image:";
        this.imageSelectionLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.imageSelectionDropdown             = new ComboBox( this );
        this.imageSelectionDropdown.editEnabled = false;

        let windows        = ImageWindow.windows;
        let activeWindowId = getActiveWindowIdSafe();
        for ( let i = 0; i < windows.length; ++i )
        {
            let id = windows[i].mainView.id;
            this._windowIds.push( id );
            this.imageSelectionDropdown.addItem( id );
            if ( id == activeWindowId )
                this.imageSelectionDropdown.currentItem = i;
        }
        if ( SyQonPrismParameters.targetViewId && SyQonPrismParameters.targetViewId.length > 0 )
            this.selectViewById( SyQonPrismParameters.targetViewId );

        this.imageSelectionDropdown.onItemSelected = index =>
        {
            if ( index >= 0 && index < this._windowIds.length )
            {
                SyQonPrismParameters.targetViewId = this._windowIds[index];
                let w = resolveWindowFromViewId( SyQonPrismParameters.targetViewId );
                SyQonPrismParameters.targetView = w ? w.mainView : undefined;
            }
        };

        this.imageSelectionSizer = new HorizontalSizer; this.imageSelectionSizer.spacing = 4;
        this.imageSelectionSizer.add( this.imageSelectionLabel );
        this.imageSelectionSizer.add( this.imageSelectionDropdown, 100 );

        // ── Model kind ──
        this.modelKindLabel = new Label( this );
        this.modelKindLabel.text          = "Model:";
        this.modelKindLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.modelKindCombo = new ComboBox( this );
        this.modelKindCombo.addItem( "prism_mini" ); this.modelKindCombo.addItem( "prism_deep" );
        this.modelKindCombo.currentItem    = (SyQonPrismParameters.modelKind == "prism_mini") ? 0 : 1;
        this.modelKindCombo.onItemSelected = index =>
        {
            SyQonPrismParameters.modelKind = this.modelKindCombo.itemText( index );
        };

        this.modelKindSizer = new HorizontalSizer; this.modelKindSizer.spacing = 4;
        this.modelKindSizer.add( this.modelKindLabel ); this.modelKindSizer.add( this.modelKindCombo, 100 );

        // ── Tile / Overlap / Pad SpinBoxes ──
        const makeSpinner = ( labelText, min, max, step, val, onUpdate ) =>
        {
            let lbl = new Label( this );
            lbl.text = labelText; lbl.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
            let sp = new SpinBox( this );
            sp.minValue = min; sp.maxValue = max; sp.stepSize = step; sp.value = val;
            sp.onValueUpdated = onUpdate;
            let sz = new HorizontalSizer; sz.spacing = 4;
            sz.add( lbl ); sz.add( sp ); sz.addStretch();
            return { label: lbl, spin: sp, sizer: sz };
        };

        let tileRow    = makeSpinner( "Tile Size:", 128, 2048,  64, SyQonPrismParameters.tileSize,  v => { SyQonPrismParameters.tileSize  = v; } );
        let overlapRow = makeSpinner( "Overlap:",     8,  512,   8, SyQonPrismParameters.overlap,   v => { SyQonPrismParameters.overlap   = v; } );
        let padRow     = makeSpinner( "Pad:",         0, 2048,   8, SyQonPrismParameters.pad,       v => { SyQonPrismParameters.pad       = v; } );

        this.tileLabel    = tileRow.label;    this.tileSpin    = tileRow.spin;    this.tileSizer    = tileRow.sizer;
        this.overlapLabel = overlapRow.label; this.overlapSpin = overlapRow.spin; this.overlapSizer = overlapRow.sizer;
        this.padLabel     = padRow.label;     this.padSpin     = padRow.spin;     this.padSizer     = padRow.sizer;

        // ── Strength ──
        this.strengthLabel = new Label( this );
        this.strengthLabel.text          = "Strength:";
        this.strengthLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.strengthSpin = new NumericControl( this );
        this.strengthSpin.label.text = "";
        this.strengthSpin.setRange( 0.0, 1.0 ); this.strengthSpin.slider.setRange( 0, 100 );
        this.strengthSpin.setPrecision( 2 ); this.strengthSpin.setValue( SyQonPrismParameters.strength );
        this.strengthSpin.onValueUpdated = value => { SyQonPrismParameters.strength = value; };

        this.strengthSizer = new HorizontalSizer; this.strengthSizer.spacing = 4;
        this.strengthSizer.add( this.strengthLabel ); this.strengthSizer.add( this.strengthSpin, 100 );

        // ── MTF ──
        this.useMTFCheckbox         = new CheckBox( this );
        this.useMTFCheckbox.text    = "Use PI Temp Stretch";
        this.useMTFCheckbox.checked = SyQonPrismParameters.useMTF;
        this.useMTFCheckbox.toolTip = "Applies a temporary stretch in PixInsight before sending to Prism, then reverses it afterward.";
        this.useMTFCheckbox.onCheck = checked =>
        {
            SyQonPrismParameters.useMTF    = checked;
            this.mtfTargetSpin.enabled     = checked;
        };

        this.mtfTargetLabel = new Label( this );
        this.mtfTargetLabel.text          = "MTF Target:";
        this.mtfTargetLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.mtfTargetSpin = new NumericControl( this );
        this.mtfTargetSpin.label.text = "";
        this.mtfTargetSpin.setRange( 0.01, 0.50 ); this.mtfTargetSpin.slider.setRange( 1, 50 );
        this.mtfTargetSpin.setPrecision( 3 ); this.mtfTargetSpin.setValue( SyQonPrismParameters.mtfTarget );
        this.mtfTargetSpin.enabled       = SyQonPrismParameters.useMTF;
        this.mtfTargetSpin.onValueUpdated = value => { SyQonPrismParameters.mtfTarget = value; };

        this.mtfTargetSizer = new HorizontalSizer; this.mtfTargetSizer.spacing = 4;
        this.mtfTargetSizer.add( this.mtfTargetLabel ); this.mtfTargetSizer.add( this.mtfTargetSpin, 100 );

        // ── AMP ──
        this.useAMPCheckbox         = new CheckBox( this );
        this.useAMPCheckbox.text    = "Use AMP";
        this.useAMPCheckbox.checked = SyQonPrismParameters.useAMP;
        this.useAMPCheckbox.toolTip = "Use mixed precision where supported.";
        this.useAMPCheckbox.onCheck = checked =>
        {
            SyQonPrismParameters.useAMP  = checked;
            this.ampDTypeCombo.enabled   = checked;
        };

        this.ampDTypeLabel = new Label( this );
        this.ampDTypeLabel.text          = "AMP Type:";
        this.ampDTypeLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;

        this.ampDTypeCombo = new ComboBox( this );
        this.ampDTypeCombo.addItem( "fp16" ); this.ampDTypeCombo.addItem( "bf16" );
        this.ampDTypeCombo.currentItem    = (SyQonPrismParameters.ampDType == "bf16") ? 1 : 0;
        this.ampDTypeCombo.enabled        = SyQonPrismParameters.useAMP;
        this.ampDTypeCombo.onItemSelected = index => { SyQonPrismParameters.ampDType = this.ampDTypeCombo.itemText( index ); };

        this.ampSizer = new HorizontalSizer; this.ampSizer.spacing = 4;
        this.ampSizer.add( this.ampDTypeLabel ); this.ampSizer.add( this.ampDTypeCombo, 100 );

        // ── CPU / DML ──
        this.useCPUCheckbox         = new CheckBox( this );
        this.useCPUCheckbox.text    = "Force CPU";
        this.useCPUCheckbox.checked = SyQonPrismParameters.useCPU;
        this.useCPUCheckbox.toolTip = "Force CPU inference.";
        this.useCPUCheckbox.onCheck = checked => { SyQonPrismParameters.useCPU = checked; };

        this.noDMLCheckbox         = new CheckBox( this );
        this.noDMLCheckbox.text    = "Disable DirectML";
        this.noDMLCheckbox.checked = SyQonPrismParameters.noDML;
        this.noDMLCheckbox.toolTip = "Disable DirectML preference on Windows.";
        this.noDMLCheckbox.onCheck = checked => { SyQonPrismParameters.noDML = checked; };

        // ── Output timeout ──
        let timeoutRow = makeSpinner( "Output Timeout (min):", 1, 240, 1,
            SyQonPrismParameters.outputTimeoutMinutes, v => { SyQonPrismParameters.outputTimeoutMinutes = v; } );
        this.outputTimeoutLabel       = timeoutRow.label;
        this.outputTimeoutSpin        = timeoutRow.spin;
        this.outputTimeoutSpin.toolTip = "Maximum time to wait for the Prism output file before aborting.";
        this.outputTimeoutSizer       = timeoutRow.sizer;

        // ── Setup button / exe path ──
        this.setupButton         = new ToolButton( this );
        this.setupButton.icon    = this.scaledResource( ":/icons/wrench.png" );
        this.setupButton.setScaledFixedSize( 24, 24 );
        this.setupButton.toolTip = "Select the Prism executable file.";
        this.setupButton.onClick = () =>
        {
            let ofd = new OpenFileDialog;
            ofd.caption            = "Select Prism Executable";
            ofd.multipleSelections = false;
            if ( SyQonPrismParameters.prismExePath.length > 0 )
                ofd.initialPath = SyQonPrismParameters.prismExePath;
            ofd.filters = IS_WINDOWS
                ? [ ["Executable Files","*.exe"],["All Files","*"] ]
                : [ ["All Files","*"] ];
            if ( ofd.execute() )
            {
                SyQonPrismParameters.prismExePath = ofd.fileName;
                SyQonPrismParameters.save();
                this.exePathLabel.text = SyQonPrismParameters.prismExePath;
            }
        };

        this.exePathLabel          = new TextBox( this );
        this.exePathLabel.readOnly = true;
        this.exePathLabel.setFixedHeight( 48 );
        this.exePathLabel.text     = SyQonPrismParameters.prismExePath.length > 0
            ? SyQonPrismParameters.prismExePath
            : "No Prism executable selected.";

        // ── Open dialog checkbox ──
        this.openDialogCheckbox         = new CheckBox( this );
        this.openDialogCheckbox.text    = "Open dialog when instance is double-clicked or dropped";
        this.openDialogCheckbox.checked = SyQonPrismParameters.openDialogBox;
        this.openDialogCheckbox.toolTip =
            "If enabled, a saved process instance opens this dialog first.\n" +
            "If disabled, dropping a process instance on a view will run immediately.";
        this.openDialogCheckbox.onCheck = checked => { SyQonPrismParameters.openDialogBox = checked; };

        // ── Buttons ──
        this.okButton         = new PushButton( this );
        this.okButton.text    = "OK";
        this.okButton.onClick = () => { this.syncToParameters(); this.ok(); };

        this.cancelButton         = new PushButton( this );
        this.cancelButton.text    = "Cancel";
        this.cancelButton.onClick = () => { this.cancel(); };

        this.newInstanceButton = new ToolButton( this );
        this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstanceButton.setScaledFixedSize( 24, 24 );
        this.newInstanceButton.toolTip      = "Drag to workspace to create a new process instance";
        this.newInstanceButton.onMousePress = () => { this.syncToParameters(); this.newInstance(); };

        this.buttonsSizer = new HorizontalSizer; this.buttonsSizer.spacing = 6;
        this.buttonsSizer.add( this.newInstanceButton ); this.buttonsSizer.addStretch();
        this.buttonsSizer.add( this.okButton ); this.buttonsSizer.add( this.cancelButton );

        // ── Label width alignment ──
        let labelWidth = this.font.width( "Output Timeout (min):MMMM" );
        [ this.imageSelectionLabel, this.modelKindLabel, this.tileLabel,
          this.overlapLabel, this.padLabel, this.strengthLabel,
          this.mtfTargetLabel, this.ampDTypeLabel, this.outputTimeoutLabel
        ].forEach( lbl => lbl.setFixedWidth( labelWidth ) );

        // ── GroupBoxes ──
        const makeGroup = ( title, ...items ) =>
        {
            let gb   = new GroupBox( this );
            gb.title = title;
            gb.sizer = new VerticalSizer; gb.sizer.margin = 6; gb.sizer.spacing = 4;
            items.forEach( it => gb.sizer.add( it ) );
            return gb;
        };

        this.imageGroup       = makeGroup( "Target Image",   this.imageSelectionSizer );
        this.modelGroup       = makeGroup( "Model Settings", this.modelKindSizer, this.tileSizer, this.overlapSizer, this.padSizer );
        this.denoiseGroup     = makeGroup( "Denoise",        this.strengthSizer, this.useMTFCheckbox, this.mtfTargetSizer );
        this.performanceGroup = makeGroup( "Performance",    this.useAMPCheckbox, this.ampSizer, this.useCPUCheckbox, this.noDMLCheckbox );
        this.advancedGroup    = makeGroup( "Advanced",       this.outputTimeoutSizer, this.openDialogCheckbox );

        this.executableGroup       = new GroupBox( this );
        this.executableGroup.title = "Prism Executable";
        let exePathSizer = new HorizontalSizer; exePathSizer.spacing = 6;
        exePathSizer.add( this.setupButton ); exePathSizer.add( this.exePathLabel, 100 );
        this.executableGroup.sizer = new VerticalSizer;
        this.executableGroup.sizer.margin = 6; this.executableGroup.sizer.spacing = 4;
        this.executableGroup.sizer.add( exePathSizer );

        // ── Copyright ──
        this.copyrightLabel = new Label( this );
        this.copyrightLabel.useRichText   = true;
        this.copyrightLabel.textAlignment = TextAlignment.Center;
        this.copyrightLabel.text = "<font size='-1'>\u00A9 SyQon 2026 \u2014 www.syqon.it</font>";

        // ── Main sizer ──
        this.sizer = new VerticalSizer; this.sizer.margin = 12; this.sizer.spacing = 8;
        this.sizer.add( this.headerLabel );
        this.sizer.add( this.headerSeparator );
        this.sizer.addSpacing( 4 );
        this.sizer.add( this.imageGroup );
        this.sizer.add( this.modelGroup );
        this.sizer.add( this.denoiseGroup );
        this.sizer.add( this.performanceGroup );
        this.sizer.add( this.advancedGroup );
        this.sizer.add( this.executableGroup );
        this.sizer.addSpacing( 8 );
        this.sizer.add( this.buttonsSizer );
        this.sizer.addSpacing( 2 );
        this.sizer.add( this.copyrightLabel );

        this.windowTitle = "SyQon Prism " + VERSION;
        this.setMinWidth( 560 );
        this.adjustToContents();

        if ( SyQonPrismParameters.targetViewId && SyQonPrismParameters.targetViewId.length > 0 )
            this.selectViewById( SyQonPrismParameters.targetViewId );
    }

    syncToParameters()
    {
        SyQonPrismParameters.modelKind            = this.modelKindCombo.itemText( this.modelKindCombo.currentItem );
        SyQonPrismParameters.tileSize             = this.tileSpin.value;
        SyQonPrismParameters.overlap              = this.overlapSpin.value;
        SyQonPrismParameters.pad                  = this.padSpin.value;
        SyQonPrismParameters.strength             = this.strengthSpin.value;
        SyQonPrismParameters.useMTF               = this.useMTFCheckbox.checked;
        SyQonPrismParameters.mtfTarget            = this.mtfTargetSpin.value;
        SyQonPrismParameters.useAMP               = this.useAMPCheckbox.checked;
        SyQonPrismParameters.ampDType             = this.ampDTypeCombo.itemText( this.ampDTypeCombo.currentItem );
        SyQonPrismParameters.useCPU               = this.useCPUCheckbox.checked;
        SyQonPrismParameters.noDML                = this.noDMLCheckbox.checked;
        SyQonPrismParameters.outputTimeoutMinutes = this.outputTimeoutSpin.value;
        SyQonPrismParameters.openDialogBox        = this.openDialogCheckbox.checked;

        let w = getSelectedWindowFromDialog( this );
        if ( w && !w.isNull )
        {
            SyQonPrismParameters.targetView   = w.mainView;
            SyQonPrismParameters.targetViewId = w.mainView.id;
        }
        SyQonPrismParameters.save();
    }

    selectViewById( viewId )
    {
        if ( !viewId || viewId.length == 0 ) return false;
        for ( let i = 0; i < this._windowIds.length; ++i )
            if ( this._windowIds[i] == viewId )
            {
                this.imageSelectionDropdown.currentItem = i;
                return true;
            }
        return false;
    }
};

// ============================================================================
// Main
// ============================================================================

function main()
{
    console.show();
    console.criticalln( " ███████╗██╗   ██╗ ██████╗  ██████╗ ███╗   ██╗" );
    console.criticalln( " ██╔════╝╚██╗ ██╔╝██╔═══██╗██╔═══██╗████╗  ██║" );
    console.criticalln( " ███████╗ ╚████╔╝ ██║   ██║██║   ██║██╔██╗ ██║" );
    console.warningln(  " ╚════██║  ╚██╔╝  ██║▄▄ ██║██║   ██║██║╚██╗██║" );
    console.warningln(  " ███████║   ██║   ╚██████╔╝╚█████╔╝ ██║ ╚████║" );
    console.warningln(  " ╚══════╝   ╚═╝    ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═══╝" );
    console.noteln( "Starting SyQon \u2605 P R I S M \u2605  " + VERSION );
    console.noteln( "\u00A9 SyQon 2026 \u2014 www.syqon.it" );
    console.flush();

    SyQonPrismParameters.load();

    if ( Parameters.isGlobalTarget )
    {
        console.criticalln( "This script cannot run in a global context." );
        return;
    }

    if ( Parameters.isViewTarget && Parameters.targetView )
    {
        SyQonPrismParameters.targetView   = Parameters.targetView;
        SyQonPrismParameters.targetViewId = Parameters.targetView.id;
        SyQonPrismParameters.save();

        if ( SyQonPrismParameters.openDialogBox )
        {
            let dlg = new SyQonPrismDialog();
            dlg.selectViewById( SyQonPrismParameters.targetViewId );
            if ( dlg.execute() )
            {
                let selectedWindow = getSelectedWindowFromDialog( dlg )
                    || resolveWindowFromViewId( SyQonPrismParameters.targetViewId );
                executePrismOnWindow( selectedWindow );
            }
            else { console.noteln( "SyQon Prism dialog closed." ); }
            return;
        }

        executePrismOnWindow( Parameters.targetView.window );
        return;
    }

    let dlg = new SyQonPrismDialog();
    if ( dlg.execute() )
    {
        let selectedWindow = getSelectedWindowFromDialog( dlg );
        if ( !selectedWindow && SyQonPrismParameters.targetViewId.length > 0 )
            selectedWindow = resolveWindowFromViewId( SyQonPrismParameters.targetViewId );
        if ( !selectedWindow )
            throw new Error( "Please select an image." );
        executePrismOnWindow( selectedWindow );
    }
    else { console.noteln( "SyQon Prism dialog closed." ); }
}

main();
