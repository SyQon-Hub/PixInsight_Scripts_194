#feature-id SyQonStudio : SyQon > Studio
#feature-icon  syqonstudio.svg
#feature-info This script drives the SyQon Studio neural CLI (syqon-cli) to run any SyQon model \
              (Prism, Parallax, Axiom/Starless, Deep Gradient) on the active image.

/****************************************************************************
 * ███████╗██╗   ██╗ ██████╗  ██████╗ ███╗   ██╗
 * ██╔════╝╚██╗ ██╔╝██╔═══██╗██╔═══██╗████╗  ██║
 * ███████╗ ╚████╔╝ ██║   ██║██║   ██║██╔██╗ ██║
 * ╚════██║  ╚██╔╝  ██║▄▄ ██║██║   ██║██║╚██╗██║
 * ███████║   ██║   ╚██████╔╝╚█████╔╝ ██║ ╚████║
 * ╚══════╝   ╚═╝    ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═══╝
 *      ★  S T U D I O  ★  (SpiderMonkey build)
 *
 * SyQon Studio PixInsight Integration
 * Version: v1.0.1
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * Consolidated integration for SyQon Studio's local neural CLI (syqon-cli).
 * One stable command contract runs every SyQon model:
 *
 *     syqon-cli --model MODEL [OPTIONS] INPUT OUTPUT
 *
 * Saves the active view as a temporary 32-bit float TIFF, runs the chosen
 * model HEADLESS (progress streams as "model NN%"; on exit 0 stdout is the
 * absolute output path), then imports the result. Axiom can also emit a
 * Stars-Only image and Deep Gradient a separate gradient image; both open as
 * new views. Entitlement is bound to the signed-in Studio account (no license
 * flag); a missing model exits 4 (authenticate in Studio).
 *
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/ColorSpace.jsh>

#define VERSION "v1.0.1"

// ----------------------------------------------------------------------------
// Platform helpers
// ----------------------------------------------------------------------------

let IS_WINDOWS = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows");
let IS_MACOS   = (CoreApplication.platform == "MACOSX"   || CoreApplication.platform == "macOS");
let IS_LINUX   = (CoreApplication.platform == "Linux");

if ( !IS_WINDOWS && !IS_MACOS && !IS_LINUX )
   console.criticalln( "Unsupported platform: " + CoreApplication.platform );

let pathSeparator = IS_WINDOWS ? "\\" : "/";

// ----------------------------------------------------------------------------
// Temp / config paths
// ----------------------------------------------------------------------------

let scriptTempDir     = File.systemTempDirectory + pathSeparator + "SyQonStudioCLI";
let syqonStudioConfig = scriptTempDir + pathSeparator + "syqon_studio_config.csv";

if ( !File.directoryExists( scriptTempDir ) )
   File.createDirectory( scriptTempDir );

// ----------------------------------------------------------------------------
// Model registry (stable CLI identifiers — from `syqon-cli --list-models`)
// ----------------------------------------------------------------------------

var STUDIO_MODELS = [
   { id:"prism-essential", label:"Prism Essential \u2014 Denoise",            family:"prism",         access:"Included", contract:"Linear RGB or mono" },
   { id:"prism-advanced",  label:"Prism Deep Advanced \u2014 Denoise",        family:"prism",         access:"Licensed", contract:"Linear RGB or mono" },
   { id:"prism-ultra",     label:"Prism Deep Ultra \u2014 Denoise",           family:"prism",         access:"Licensed", contract:"Linear or non-linear" },
   { id:"prism-max",       label:"Prism Deep Max \u2014 Denoise",             family:"prism",         access:"Licensed", contract:"Linear or non-linear" },
   { id:"prism-legacy-v1", label:"Prism Legacy V1 \u2014 Denoise",            family:"prism",         access:"Licensed", contract:"Legacy display-domain input" },
   { id:"prism-legacy-v2", label:"Prism Legacy V2 \u2014 Denoise",            family:"prism",         access:"Licensed", contract:"Robust linear input" },
   { id:"parallax",        label:"Parallax \u2014 Correct / Reduce / Deblur", family:"parallax",      access:"Licensed", contract:"Linear or non-linear" },
   { id:"axiom",           label:"Axiom V3 \u2014 Starless",                  family:"axiom",         access:"Licensed", contract:"Linear (Axiom stretch) or non-linear" },
   { id:"deep-gradient",   label:"Deep Gradient \u2014 Gradient removal",     family:"deep-gradient", access:"Included", contract:"Linear RGB or mono" }
];

function modelById( id ) {
   for ( let i = 0; i < STUDIO_MODELS.length; ++i )
      if ( STUDIO_MODELS[i].id == id ) return STUDIO_MODELS[i];
   return STUDIO_MODELS[0];
}

function exitCodeMessage( code ) {
   switch ( code ) {
   case 1: return "General CLI error. The original image was kept.";
   case 2: return "Invalid option or incompatible domain. Try declaring the input " +
                  "domain explicitly (Linear / Non-linear) \u2014 some models require linear input.";
   case 3: return "Input/output path error (existence, permissions, or overwrite policy).";
   case 4: return "Authentication or entitlement denied. Sign in through SyQon Studio " +
                  "and confirm this model is available to your account.";
   case 5: return "Inference failed \u2014 no output was produced.";
   case 6: return "Output encoding failed. Try a different precision or destination.";
   case 7: return "Output was saved, but the Studio handoff step failed.";
   default: return "SyQon CLI exited with code " + code + ".";
   }
}

// ----------------------------------------------------------------------------
// Parameters
// ----------------------------------------------------------------------------

var P = {
   targetView:           undefined,
   targetViewId:         "",
   cliPath:              "",

   modelId:              "prism-essential",
   domain:               "auto",
   precision:            "f32",
   tileSize:             512,
   overlap:              64,
   application:          1.0,

   parallaxFamily:       "aesthetics",
   pxCorrection:         true,
   pxReduction:          true,
   pxReductionLevel:     5,
   pxDeblur:             true,
   pxDeblurStrength:     0.5,

   axiomStretch:         "auto",
   axiomBlack:           0.0,
   axiomMid:             0.25,
   axiomWhite:           1.0,
   axiomMakeStars:       true,

   dgMakeGradient:       false,

   outputTimeoutMinutes: 30,
   openDialogBox:        true,

   save: function() {
      Parameters.set( "targetViewId",         this.targetViewId );
      Parameters.set( "modelId",              this.modelId );
      Parameters.set( "domain",               this.domain );
      Parameters.set( "precision",            this.precision );
      Parameters.set( "tileSize",             this.tileSize );
      Parameters.set( "overlap",              this.overlap );
      Parameters.set( "application",          this.application );
      Parameters.set( "parallaxFamily",       this.parallaxFamily );
      Parameters.set( "pxCorrection",         this.pxCorrection );
      Parameters.set( "pxReduction",          this.pxReduction );
      Parameters.set( "pxReductionLevel",     this.pxReductionLevel );
      Parameters.set( "pxDeblur",             this.pxDeblur );
      Parameters.set( "pxDeblurStrength",     this.pxDeblurStrength );
      Parameters.set( "axiomStretch",         this.axiomStretch );
      Parameters.set( "axiomBlack",           this.axiomBlack );
      Parameters.set( "axiomMid",             this.axiomMid );
      Parameters.set( "axiomWhite",           this.axiomWhite );
      Parameters.set( "axiomMakeStars",       this.axiomMakeStars );
      Parameters.set( "dgMakeGradient",       this.dgMakeGradient );
      Parameters.set( "outputTimeoutMinutes", this.outputTimeoutMinutes );
      Parameters.set( "openDialogBox",        this.openDialogBox );
      this.savePathToFile();
   },

   load: function() {
      if ( Parameters.has( "targetViewId" ) )         this.targetViewId        = Parameters.getString(  "targetViewId" );
      if ( Parameters.has( "modelId" ) )              this.modelId             = Parameters.getString(  "modelId" );
      if ( Parameters.has( "domain" ) )               this.domain              = Parameters.getString(  "domain" );
      if ( Parameters.has( "precision" ) )            this.precision           = Parameters.getString(  "precision" );
      if ( Parameters.has( "tileSize" ) )             this.tileSize            = Parameters.getInteger( "tileSize" );
      if ( Parameters.has( "overlap" ) )              this.overlap             = Parameters.getInteger( "overlap" );
      if ( Parameters.has( "application" ) )          this.application         = Parameters.getReal(    "application" );
      if ( Parameters.has( "parallaxFamily" ) )       this.parallaxFamily      = Parameters.getString(  "parallaxFamily" );
      if ( Parameters.has( "pxCorrection" ) )         this.pxCorrection        = Parameters.getBoolean( "pxCorrection" );
      if ( Parameters.has( "pxReduction" ) )          this.pxReduction         = Parameters.getBoolean( "pxReduction" );
      if ( Parameters.has( "pxReductionLevel" ) )     this.pxReductionLevel    = Parameters.getInteger( "pxReductionLevel" );
      if ( Parameters.has( "pxDeblur" ) )             this.pxDeblur            = Parameters.getBoolean( "pxDeblur" );
      if ( Parameters.has( "pxDeblurStrength" ) )     this.pxDeblurStrength    = Parameters.getReal(    "pxDeblurStrength" );
      if ( Parameters.has( "axiomStretch" ) )         this.axiomStretch        = Parameters.getString(  "axiomStretch" );
      if ( Parameters.has( "axiomBlack" ) )           this.axiomBlack          = Parameters.getReal(    "axiomBlack" );
      if ( Parameters.has( "axiomMid" ) )             this.axiomMid            = Parameters.getReal(    "axiomMid" );
      if ( Parameters.has( "axiomWhite" ) )           this.axiomWhite          = Parameters.getReal(    "axiomWhite" );
      if ( Parameters.has( "axiomMakeStars" ) )       this.axiomMakeStars      = Parameters.getBoolean( "axiomMakeStars" );
      if ( Parameters.has( "dgMakeGradient" ) )       this.dgMakeGradient      = Parameters.getBoolean( "dgMakeGradient" );
      if ( Parameters.has( "outputTimeoutMinutes" ) ) this.outputTimeoutMinutes = Parameters.getInteger( "outputTimeoutMinutes" );
      if ( Parameters.has( "openDialogBox" ) )        this.openDialogBox       = Parameters.getBoolean( "openDialogBox" );

      this.loadPathFromFile();

      this.targetView = undefined;
      if ( this.targetViewId && this.targetViewId.length > 0 ) {
         let w = ImageWindow.windowById( this.targetViewId );
         if ( w && !w.isNull ) this.targetView = w.mainView;
      }
      if ( Parameters.isViewTarget && Parameters.targetView ) {
         this.targetView   = Parameters.targetView;
         this.targetViewId = Parameters.targetView.id;
      }
   },

   savePathToFile: function() {
      try {
         let file = new File;
         file.createForWriting( syqonStudioConfig );
         file.outTextLn( String( this.cliPath || "" ) );
         file.close();
      } catch ( error ) {
         console.warningln( "Failed to save CLI path: " + error.message );
      }
   },

   loadPathFromFile: function() {
      try {
         if ( File.exists( syqonStudioConfig ) ) {
            let lines = File.readLines( syqonStudioConfig );
            if ( lines.length > 0 && (!this.cliPath || this.cliPath.length == 0) )
               this.cliPath = lines[0].trim();
         }
      } catch ( error ) {
         console.warningln( "Failed to load CLI path: " + error.message );
      }
      if ( !this.cliPath || this.cliPath.length == 0 )
         this.cliPath = findSyqonCli();
   }
};

// ----------------------------------------------------------------------------
// CLI discovery / validation
// ----------------------------------------------------------------------------

function envVar( name ) {
   try {
      if ( typeof System != "undefined" && System.getEnvironmentVariable ) {
         let v = System.getEnvironmentVariable( name );
         return v ? String( v ) : "";
      }
      let v = getEnvironmentVariable( name );
      return v ? String( v ) : "";
   } catch ( e ) { return ""; }
}

function resolveBundle( p ) {
   if ( !p ) return p;
   if ( IS_MACOS && p.length >= 4 && p.substring( p.length - 4 ) == ".app" && File.directoryExists( p ) ) {
      let inner = p + "/Contents/MacOS/syqon-cli";
      if ( File.exists( inner ) ) return inner;
   }
   return p;
}

function validateCli( exePath ) {
   let exe = resolveBundle( exePath );
   if ( !exe || exe.length == 0 || !File.exists( exe ) )
      return false;
   try {
      let proc = new ExternalProcess;
      proc.start( exe, [ "--version" ] );
      proc.waitForStarted( 3000 );
      proc.waitForFinished( 8000 );
      return proc.exitCode == 0;
   } catch ( e ) { return false; }
}

function windowsRegistryCli() {
   if ( !IS_WINDOWS ) return "";
   try {
      let proc = new ExternalProcess;
      proc.start( "reg", [ "query",
         "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\App Paths\\syqon-cli.exe", "/ve" ] );
      proc.waitForStarted( 3000 );
      proc.waitForFinished( 5000 );
      let out = String( proc.stdout || "" );
      let m = out.match( /REG_SZ\s+(.+?)\s*$/m );
      return m ? m[1].trim() : "";
   } catch ( e ) { return ""; }
}

function syqonCliCandidates() {
   let out = [];
   let env = envVar( "SYQON_CLI_PATH" );
   if ( env.length > 0 ) out.push( env );

   if ( IS_MACOS ) {
      out.push( "/Applications/SyQon Studio.app/Contents/MacOS/syqon-cli" );
      let home = envVar( "HOME" );
      if ( home.length > 0 )
         out.push( home + "/Applications/SyQon Studio.app/Contents/MacOS/syqon-cli" );
   } else if ( IS_WINDOWS ) {
      let reg = windowsRegistryCli();
      if ( reg.length > 0 ) out.push( reg );
      let local = envVar( "LOCALAPPDATA" );
      if ( local.length > 0 )
         out.push( local + "\\Programs\\SyQon Studio\\syqon-cli.exe" );
      out.push( "C:\\Program Files\\SyQon Studio\\syqon-cli.exe" );
   }
   return out;
}

function findSyqonCli() {
   let cands = syqonCliCandidates();
   for ( let i = 0; i < cands.length; ++i ) {
      let c = resolveBundle( cands[i] );
      if ( c && File.exists( c ) && validateCli( c ) )
         return c;
   }
   return "";
}

// ----------------------------------------------------------------------------
// Utility helpers
// ----------------------------------------------------------------------------

function resolveWindowFromViewId( viewId ) {
   if ( !viewId || viewId.length == 0 ) return null;
   let w = ImageWindow.windowById( viewId );
   return (w && !w.isNull) ? w : null;
}

function getSelectedWindowFromDialog( dialog ) {
   if ( !dialog ) return null;
   let idx = dialog.imageSelectionDropdown.currentItem;
   if ( idx < 0 || idx >= dialog._windowIds.length ) return null;
   return resolveWindowFromViewId( dialog._windowIds[idx] );
}

function sanitizeFileName( name ) { return name.replace( /[^A-Za-z0-9_\-]/g, "_" ); }

function deleteFileIfExists( filePath ) {
   try {
      if ( File.exists( filePath ) ) { File.remove( filePath ); console.writeln( "Deleted: " + filePath ); }
   } catch ( error ) { console.warningln( "Failed to delete: " + filePath + " -> " + error.message ); }
}

function getActiveWindowIdSafe() {
   try { return ImageWindow.activeWindow.mainView.id; } catch ( e ) { return ""; }
}

function ensureTempDirExists() {
   if ( !File.directoryExists( scriptTempDir ) ) File.createDirectory( scriptTempDir );
}

function buildRunPaths( baseName ) {
   ensureTempDirExists();
   let runTag   = String( (new Date()).getTime() );
   let safeBase = sanitizeFileName( baseName );
   let stem     = scriptTempDir + pathSeparator + safeBase + "_" + runTag;
   return {
      inputFilePath:    stem + "_input.xisf",
      outputFilePath:   stem + "_output.xisf",
      starsFilePath:    stem + "_stars.xisf",
      gradientFilePath: stem + "_gradient.xisf"
   };
}

function makeUniqueViewId( baseId ) {
   return sanitizeFileName( baseId ) + "_" + String( (new Date()).getTime() );
}

function formatElapsed( ms ) {
   let s = Math.max( 0, Math.floor( ms / 1000 ) );
   let h = Math.floor( s / 3600 ); s -= h * 3600;
   let m = Math.floor( s / 60 );   s -= m * 60;
   return h > 0 ? format( "%d:%02d:%02d", h, m, s ) : format( "%02d:%02d", m, s );
}

function cloneWindowForProcessing( sourceWindow, newId ) {
   let src = sourceWindow.mainView.image;
   // Force a 32-bit float working copy so scientific samples round-trip exactly
   // through XISF regardless of the source's stored bit depth.
   let w   = new ImageWindow( src.width, src.height, src.numberOfChannels,
                              32, true, src.isColor, newId );
   w.mainView.beginProcess( UndoFlag_NoSwapFile );
   w.mainView.image.assign( src );
   w.mainView.endProcess();
   return w;
}

function saveImageAsXISF( filePath, view ) {
   // Write PixInsight's NATIVE format. Studio reads XISF directly, and writing
   // XISF avoids whatever PixInsight's TIFF encoder was doing that made linear
   // images come back black from the CLI.
   let F = new FileFormat( "XISF", false, true );
   if ( F.isNull ) throw new Error( "XISF file format not available." );
   let f = new FileFormatInstance( F );
   if ( f.isNull ) throw new Error( "Unable to create FileFormatInstance for XISF." );

   let description = new ImageDescription();
   description.bitsPerSample      = 32;
   description.ieeefpSampleFormat = true;

   if ( !f.create( filePath, "" ) )
      throw new Error( "Unable to create XISF file: " + filePath );
   if ( !f.setOptions( description ) ) { f.close(); throw new Error( "Unable to set 32-bit float XISF options." ); }
   if ( !f.writeImage( view.image ) )  { f.close(); throw new Error( "Failed to write XISF: " + filePath ); }
   f.close();
   console.writeln( "Saved 32-bit float XISF: " + filePath );
   return filePath;
}

function _pmApply( view, expr ) {
   let pm = new PixelMath;
   pm.useSingleExpression = true;
   pm.expression          = expr;
   pm.createNewImage      = false;
   pm.rescale             = false;
   pm.truncate            = false;
   pm.executeOn( view );
}

function sanitizeForStudio( view ) {
   // Match SASpro's pre-CLI prep: scrub non-finite samples to 0, normalize only
   // if the image exceeds ~1.0, then clip to [0,1]. Linear astro data routinely
   // carries negative background pixels (and sometimes NaN/Inf); a [0,1]-trained
   // model fed those returns a black image. Returns the scale factor to re-apply
   // to the result on import.
   _pmApply( view, "iif( $T == $T && abs( $T ) < 1e30, $T, 0 )" );   // NaN / ±Inf -> 0
   let mx = view.image.maximum();
   let scale = ( isFinite( mx ) && mx > 1.01 ) ? mx : 1.0;
   if ( scale > 1.01 )
      _pmApply( view, "max( 0, min( 1, $T/" + format( "%.10f", scale ) + " ) )" );
   else
      _pmApply( view, "max( 0, min( 1, $T ) )" );
   return scale;
}

function openImageFile( filePath, label ) {
   if ( !File.exists( filePath ) ) throw new Error( label + " file not found: " + filePath );
   let opened = ImageWindow.open( filePath );
   if ( !opened || opened.length < 1 ) throw new Error( "Failed to open " + label + ": " + filePath );
   return opened[0];
}

// ----------------------------------------------------------------------------
// Output processing
// ----------------------------------------------------------------------------

function applyResultToTarget( targetWindow, resultWindow, scale ) {
   let resultId = resultWindow.mainView.id;
   if ( !targetWindow.mainView.image.isColor && resultWindow.mainView.image.isColor )
      resultId = resultId + "[0]";
   // Re-apply the input scale (if we normalized a >1 image) and clip to [0,1],
   // mirroring SASpro's readback (arr*scale then clip).
   let expr = ( scale && scale > 1.01 )
      ? "(" + resultId + ")*" + format( "%.10f", scale )
      : resultId;
   let pm = new PixelMath;
   pm.useSingleExpression = true;
   pm.expression          = expr;
   pm.createNewImage      = false;
   pm.rescale             = false;
   pm.truncate            = true; pm.truncateLower = 0; pm.truncateUpper = 1;
   pm.executeOn( targetWindow.mainView );
}

function openSecondaryAsView( filePath, newId, label ) {
   if ( !File.exists( filePath ) ) return;
   try {
      let w = openImageFile( filePath, label );
      try { w.mainView.id = newId; } catch ( e ) {}
      w.show();
      console.noteln( "Opened " + label + " view: " + w.mainView.id );
   } catch ( e ) { console.warningln( "Could not open " + label + ": " + e.message ); }
}

function processStudioOutput( runPaths, targetWindow, scale ) {
   let m = modelById( P.modelId );
   let resultWindow = openImageFile( runPaths.outputFilePath, "Result" );
   try {
      if ( m.family == "axiom" && P.axiomMakeStars )
         openSecondaryAsView( runPaths.starsFilePath,
                              makeUniqueViewId( targetWindow.mainView.id + "_StarsOnly" ), "Stars Only" );
      if ( m.family == "deep-gradient" && P.dgMakeGradient )
         openSecondaryAsView( runPaths.gradientFilePath,
                              makeUniqueViewId( targetWindow.mainView.id + "_Gradient" ), "Gradient" );
      applyResultToTarget( targetWindow, resultWindow, scale );
   } finally {
      resultWindow.forceClose();
      deleteFileIfExists( runPaths.outputFilePath );
   }
}

// ----------------------------------------------------------------------------
// CLI argument construction
// ----------------------------------------------------------------------------

function buildStudioArgs( inputFilePath, outputFilePath, starsPath, gradientPath ) {
   let m = modelById( P.modelId );
   let fam = m.family;
   let args = [];
   args.push( "--model" ); args.push( P.modelId );
   args.push( "--domain" ); args.push( P.domain );
   args.push( "--precision" ); args.push( P.precision );

   if ( fam == "prism" || fam == "parallax" ) {
      args.push( "--tile-size" ); args.push( String( P.tileSize ) );
      args.push( "--overlap" );   args.push( String( P.overlap ) );
   }

   if ( fam == "prism" ) {
      args.push( "--application" ); args.push( format( "%.4f", P.application ) );
   } else if ( fam == "parallax" ) {
      args.push( "--family" );     args.push( P.parallaxFamily );
      args.push( "--correction" ); args.push( P.pxCorrection ? "true" : "false" );
      args.push( "--reduction" );  args.push( P.pxReduction  ? "true" : "false" );
      if ( P.pxReduction ) { args.push( "--reduction-level" ); args.push( String( P.pxReductionLevel ) ); }
      args.push( "--deblur" );     args.push( P.pxDeblur ? "true" : "false" );
      if ( P.pxDeblur ) { args.push( "--deblur-strength" ); args.push( format( "%.4f", P.pxDeblurStrength ) ); }
   } else if ( fam == "axiom" ) {
      args.push( "--axiom-stretch" ); args.push( P.axiomStretch );
      if ( P.axiomStretch == "custom" ) {
         args.push( "--axiom-black" ); args.push( format( "%.6f", P.axiomBlack ) );
         args.push( "--axiom-mid" );   args.push( format( "%.6f", P.axiomMid ) );
         args.push( "--axiom-white" ); args.push( format( "%.6f", P.axiomWhite ) );
      }
      if ( P.axiomMakeStars && starsPath ) { args.push( "--stars-output" ); args.push( starsPath ); }
   } else if ( fam == "deep-gradient" ) {
      if ( P.dgMakeGradient && gradientPath ) { args.push( "--gradient-output" ); args.push( gradientPath ); }
   }

   args.push( "--overwrite" );
   args.push( inputFilePath );
   args.push( outputFilePath );
   return args;
}

// ----------------------------------------------------------------------------
// executeStudioOnWindow
// ----------------------------------------------------------------------------

function executeStudioOnWindow( targetWindow ) {
   let tempInput = "";
   let tempClone = null;

   try {
      if ( !targetWindow || targetWindow.isNull )
         throw new Error( "No valid target image selected." );

      let exe = resolveBundle( P.cliPath );
      if ( !exe || exe.length == 0 || !File.exists( exe ) )
         throw new Error( "SyQon Studio CLI not found. Use the wrench button to locate syqon-cli." );

      let m = modelById( P.modelId );
      if ( m.family == "parallax" && !P.pxCorrection && !P.pxReduction && !P.pxDeblur )
         throw new Error( "Parallax needs at least one stage enabled (correction, reduction, or deblur)." );

      P.targetView   = targetWindow.mainView;
      P.targetViewId = targetWindow.mainView.id;
      P.save();

      let runPaths = buildRunPaths( targetWindow.mainView.id );
      tempInput = runPaths.inputFilePath;

      let cloneId = makeUniqueViewId( targetWindow.mainView.id + "_StudioTemp" );
      tempClone = cloneWindowForProcessing( targetWindow, cloneId );
      // Match SASpro: scrub non-finite + clip to [0,1] (and normalize if >1)
      // BEFORE writing, so linear data with negatives/NaN doesn't come back black.
      let scaleFactor = sanitizeForStudio( tempClone.mainView );
      saveImageAsXISF( tempInput, tempClone.mainView );
      tempClone.forceClose(); tempClone = null;

      let args = buildStudioArgs( runPaths.inputFilePath, runPaths.outputFilePath,
                                  runPaths.starsFilePath, runPaths.gradientFilePath );

      let controller = new StudioRunController( targetWindow, runPaths, scaleFactor );
      tempInput = "";
      controller.start( exe, args );
   } catch ( error ) {
      console.criticalln( "SyQon Studio failed: " + error.message );
   } finally {
      if ( tempClone && !tempClone.isNull ) try { tempClone.forceClose(); } catch ( e ) {}
      if ( tempInput.length > 0 ) deleteFileIfExists( tempInput );
   }
}

// ----------------------------------------------------------------------------
// StudioRunController  (headless: output-file existence == completion)
// ----------------------------------------------------------------------------

function StudioRunController( targetWindow, runPaths, scaleFactor ) {
   this.targetWindow  = targetWindow;
   this.runPaths      = runPaths;
   this.scaleFactor   = ( typeof scaleFactor === "number" ) ? scaleFactor : 1.0;
   this.process       = new ExternalProcess;
   this.waitDialog    = null;
   this.timer         = null;
   this.startTime     = 0;
   this.timeoutMs     = Math.max( 1, P.outputTimeoutMinutes || 30 ) * 60 * 1000;
   this.canceled      = false;
   this.completed     = false;
   this.cleaned       = false;
   this.stdoutBuffer  = "";
   this.stderrBuffer  = "";
   this.stdoutText    = "";
   this.lastStage     = "Launching SyQon Studio CLI...";
   this.lastPercent   = -1;
   this.processExited = false;
   this.exitCode      = -1;
   this.declaredOutput = "";
}

StudioRunController.prototype.cleanupInput = function() {
   if ( this.cleaned ) return;
   this.cleaned = true;
   deleteFileIfExists( this.runPaths.inputFilePath );
};

StudioRunController.prototype.scanPercent = function( chunk ) {
   // SyQon streams progress as in-place, carriage-return updates
   // ("model 42%\r...") that may never be newline-terminated, so scan the raw
   // chunk directly for the most recent percentage and update now.
   let last = -1, m;
   let re = /(\d+)\s*%/g;
   while ( (m = re.exec( chunk )) !== null ) last = parseInt( m[1], 10 );
   if ( last >= 0 ) {
      this.lastPercent = last;
      if ( this.lastStage.indexOf( "%" ) < 0 ) this.lastStage = "Processing...";
      if ( this.waitDialog )
         this.waitDialog.updateStatus( this.lastStage, this.lastPercent, this.startTime, this.timeoutMs );
   }
};

StudioRunController.prototype.handleLine = function( line ) {
   if ( !line ) return;
   let text = line.trim();
   if ( text.length == 0 ) return;

   let pctMatch = text.match( /(\d+)\s*%/ );
   if ( pctMatch ) {
      this.lastPercent = parseInt( pctMatch[1], 10 );
      this.lastStage   = "Processing...";
      if ( this.waitDialog )
         this.waitDialog.updateStatus( this.lastStage, this.lastPercent, this.startTime, this.timeoutMs );
      return;
   }

   if ( text.length > 3 && File.exists( text ) )
      this.declaredOutput = text;

   this.lastStage = text;
   if ( this.waitDialog )
      this.waitDialog.updateStatus( this.lastStage, this.lastPercent, this.startTime, this.timeoutMs );
   console.noteln( text );
};

StudioRunController.prototype.processBuffered = function( chunk, which ) {
   if ( !chunk || chunk.length == 0 ) return;

   // Real-time progress: parse the raw chunk before any line buffering.
   this.scanPercent( chunk );

   // Split on CR *and* LF so carriage-return progress and normal lines parse.
   if ( which == "stdout" ) {
      this.stdoutBuffer += chunk;
      this.stdoutText   += chunk;
      let lines     = this.stdoutBuffer.split( /\r\n|\r|\n/ );
      let remainder = lines.pop();
      for ( let i = 0; i < lines.length; ++i ) this.handleLine( lines[i] );
      this.stdoutBuffer = remainder;
      return;
   }
   this.stderrBuffer += chunk;
   let lines     = this.stderrBuffer.split( /\r\n|\r|\n/ );
   let remainder = lines.pop();
   for ( let i = 0; i < lines.length; ++i ) this.handleLine( lines[i] );
   this.stderrBuffer = remainder;
};

StudioRunController.prototype.start = function( exePath, args ) {
   let self = this;

   this.process.onStandardOutputDataAvailable = function() {
      self.processBuffered( String( this.stdout ), "stdout" );
   };
   this.process.onStandardErrorDataAvailable = function() {
      self.processBuffered( String( this.stderr ), "stderr" );
   };

   this.process.onStarted = function() {
      console.noteln( "SyQon Studio CLI launched." );
      console.noteln( "Executable: " + exePath );
      console.noteln( "Arguments: " + args.join( " " ) );
      self.lastStage = "Running " + P.modelId + "...";
      if ( self.waitDialog )
         self.waitDialog.updateStatus( self.lastStage, -1, self.startTime, self.timeoutMs );
   };

   this.process.onFinished = function( exitCode, exitStatus ) {
      if ( self.stdoutBuffer.length > 0 ) { self.handleLine( self.stdoutBuffer ); self.stdoutBuffer = ""; }
      if ( self.stderrBuffer.length > 0 ) { self.handleLine( self.stderrBuffer ); self.stderrBuffer = ""; }
      // 'this' is the process here; prefer its exitCode property.
      let ec = this.exitCode;
      if ( typeof ec !== "number" && typeof exitCode === "number" ) ec = exitCode;
      self.exitCode      = ( typeof ec === "number" ) ? ec : 0;
      self.processExited = true;
   };

   this.process.onError = function( code ) { console.warningln( "ExternalProcess error: " + code ); };

   this.startTime  = (new Date()).getTime();
   this.waitDialog = new StudioWaitDialog( this );
   this.waitDialog.updateStatus( "Launching SyQon Studio CLI...", -1, this.startTime, this.timeoutMs );

   try { this.process.start( exePath, args ); }
   catch ( e ) { throw new Error( "Failed to start SyQon Studio CLI: " + e.message ); }

   this._startTimer();
   this.waitDialog.execute();
};

StudioRunController.prototype._startTimer = function() {
   let self = this;
   this.timer          = new Timer;
   this.timer.interval = 0.5;
   this.timer.periodic = true;
   this.timer.onTimeout = function() { self.poll(); };
   this.timer.start();
};

StudioRunController.prototype._stopTimer = function() {
   try { if ( this.timer ) this.timer.stop(); } catch ( e ) {}
};

StudioRunController.prototype.poll = function() {
   if ( this.canceled || this.completed ) return;

   let now     = (new Date()).getTime();
   let elapsed = now - this.startTime;

   if ( this.waitDialog )
      this.waitDialog.updateStatus( this.lastStage, this.lastPercent, this.startTime, this.timeoutMs );

   // Primary completion signal: the output file exists (we passed a unique
   // per-run path; the CLI never publishes a partial output). Robust across
   // PJSR builds regardless of onFinished/exitCode delivery.
   let outPath = ( this.declaredOutput && File.exists( this.declaredOutput ) )
                 ? this.declaredOutput : this.runPaths.outputFilePath;

   if ( File.exists( outPath ) ) {
      this.completed = true;
      this._stopTimer();
      this.lastStage = "Loading result...";
      if ( this.waitDialog )
         this.waitDialog.updateStatus( this.lastStage, 99, this.startTime, this.timeoutMs );

      try { msleep( 800 ); } catch ( e ) {}
      try {
         if ( this.declaredOutput && File.exists( this.declaredOutput ) )
            this.runPaths.outputFilePath = this.declaredOutput;
         processStudioOutput( this.runPaths, this.targetWindow, this.scaleFactor );
         console.writeln( "SyQon Studio complete on: " + this.targetWindow.mainView.id );
         this.cleanupInput();
         deleteFileIfExists( this.runPaths.starsFilePath );
         deleteFileIfExists( this.runPaths.gradientFilePath );
         if ( this.waitDialog ) this.waitDialog.ok();
      } catch ( e ) {
         this.cleanupInput();
         console.criticalln( "SyQon Studio failed importing output: " + e.message );
         if ( this.waitDialog ) this.waitDialog.cancel();
      }
      return;
   }

   if ( this.processExited ) {
      this.completed = true;
      this._stopTimer();
      this.cleanupInput();
      if ( this.exitCode == 130 )
         console.warningln( "SyQon Studio was interrupted (cancellation)." );
      else if ( this.exitCode == 0 )
         console.criticalln( "SyQon Studio reported success but produced no output file." );
      else
         console.criticalln( "SyQon Studio: " + exitCodeMessage( this.exitCode ) );
      if ( this.waitDialog ) this.waitDialog.cancel();
      return;
   }

   if ( elapsed >= this.timeoutMs ) {
      this.completed = true;
      this._stopTimer();
      try { if ( this.process && this.process.isRunning ) this.process.terminate(); } catch ( e ) {}
      this.cleanupInput();
      console.criticalln( "SyQon Studio timed out before producing output." );
      if ( this.waitDialog ) this.waitDialog.cancel();
   }
};

StudioRunController.prototype.cancelWaiting = function() {
   if ( this.completed || this.canceled ) return;
   this.canceled = true;
   this._stopTimer();
   try { if ( this.process && this.process.isRunning ) this.process.terminate(); } catch ( e ) {}
   this.cleanupInput();
   console.warningln( "Cancelled \u2014 SyQon Studio CLI terminated." );
   if ( this.waitDialog ) this.waitDialog.cancel();
};

// ----------------------------------------------------------------------------
// StudioWaitDialog
// ----------------------------------------------------------------------------

function StudioWaitDialog( controller ) {
   this.__base__ = Dialog;
   this.__base__();

   let self = this;
   this.controller    = controller;
   this.windowTitle   = "SyQon Studio \u2014 Processing";
   this.userResizable = false;
   this.minWidth      = 560;

   this.waitHeaderLabel = new Label( this );
   this.waitHeaderLabel.useRichText   = true;
   this.waitHeaderLabel.textAlignment = TextAlign_Center;
   this.waitHeaderLabel.text =
      "<b><font size='+1'>\u2605 SyQon Studio \u2605</font></b><br/>" +
      "<font size='-1'>Running " + P.modelId + "</font>";

   this.headerSep = new Frame( this );
   this.headerSep.frameStyle = FrameStyle_Box;
   this.headerSep.setFixedHeight( 2 );

   this.statusGroup       = new GroupBox( this );
   this.statusGroup.title = "Status";

   this.progressLabel = new Label( this );
   this.progressLabel.useRichText = true;
   this.progressLabel.text        = "<b>Progress:</b> starting...";

   this.progressBarLabel = new Label( this );
   this.progressBarLabel.useRichText = false;
   this.progressBarLabel.text        = "";

   this.elapsedLabel = new Label( this );
   this.elapsedLabel.useRichText = true;
   this.elapsedLabel.text        = "<b>Elapsed:</b> 00:00";

   this.statusGroup.sizer = new VerticalSizer;
   this.statusGroup.sizer.margin = 8;
   this.statusGroup.sizer.spacing = 6;
   this.statusGroup.sizer.add( this.progressLabel );
   this.statusGroup.sizer.add( this.progressBarLabel );
   this.statusGroup.sizer.add( this.elapsedLabel );

   this.noteLabel = new Label( this );
   this.noteLabel.useRichText  = true;
   this.noteLabel.wordWrapping = true;
   this.noteLabel.text =
      "<i>SyQon Studio is running headlessly. Clicking Cancel terminates it immediately; " +
      "no partial result is written.</i>";

   this.cancelButton = new PushButton( this );
   this.cancelButton.text = "Cancel";
   this.cancelButton.onClick = function() { self.controller.cancelWaiting(); };

   this.buttonSizer = new HorizontalSizer;
   this.buttonSizer.addStretch();
   this.buttonSizer.add( this.cancelButton );
   this.buttonSizer.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.margin = 12;
   this.sizer.spacing = 8;
   this.sizer.add( this.waitHeaderLabel );
   this.sizer.add( this.headerSep );
   this.sizer.addSpacing( 4 );
   this.sizer.add( this.statusGroup );
   this.sizer.addSpacing( 4 );
   this.sizer.add( this.noteLabel );
   this.sizer.addSpacing( 8 );
   this.sizer.add( this.buttonSizer );
   this.adjustToContents();
}

StudioWaitDialog.prototype = new Dialog;

StudioWaitDialog.prototype.updateStatus = function( stage, percent, startTime, timeoutMs ) {
   let now     = (new Date()).getTime();
   let elapsed = now - startTime;
   let remain  = Math.max( 0, timeoutMs - elapsed );

   this.progressLabel.text = (percent >= 0)
      ? ("<b>Progress:</b> " + stage + "  [<b>" + percent + "%</b>]")
      : ("<b>Progress:</b> " + stage);

   if ( percent >= 0 ) {
      let barLen = 40;
      let filled = Math.round( barLen * percent / 100 );
      let bar    = "";
      for ( let i = 0; i < barLen; i++ ) bar += (i < filled) ? "\u2588" : "\u2591";
      this.progressBarLabel.text = bar + "  " + percent + "%";
   } else {
      this.progressBarLabel.text = "";
   }

   this.elapsedLabel.text =
      "<b>Elapsed:</b> " + formatElapsed( elapsed ) +
      "    <b>Timeout in:</b> " + formatElapsed( remain );
};

// ----------------------------------------------------------------------------
// SyQonStudioDialog
// ----------------------------------------------------------------------------

function SyQonStudioDialog() {
   this.__base__ = Dialog;
   this.__base__();

   let self = this;
   P.load();
   this._windowIds = [];

   // ── methods ──
   this.updateModelUI = function() {
      let m = modelById( P.modelId );
      self.contractLabel.text =
         "<i>Input contract: " + m.contract + " \u00B7 " +
         (m.access == "Included" ? "included with your account" : "requires a licensed entitlement") + ".</i>";

      let isPrism    = (m.family == "prism");
      let isParallax = (m.family == "parallax");
      let isAxiom    = (m.family == "axiom");
      let isGradient = (m.family == "deep-gradient");

      self.applicationControl.visible = isPrism;
      self.tileSpin.enabled    = isPrism || isParallax;
      self.overlapSpin.enabled = isPrism || isParallax;

      self.parallaxGroup.visible = isParallax;
      self.axiomGroup.visible    = isAxiom;
      self.gradientGroup.visible = isGradient;

      self.adjustToContents();
   };

   this.syncToParameters = function() {
      let w = getSelectedWindowFromDialog( self );
      if ( w && !w.isNull ) {
         P.targetView   = w.mainView;
         P.targetViewId = w.mainView.id;
      }
      P.save();
   };

   this.selectViewById = function( viewId ) {
      if ( !viewId || viewId.length == 0 ) return false;
      for ( let i = 0; i < self._windowIds.length; ++i )
         if ( self._windowIds[i] == viewId ) { self.imageSelectionDropdown.currentItem = i; return true; }
      return false;
   };

   // ── Header ──
   this.headerLabel = new Label( this );
   this.headerLabel.useRichText   = true;
   this.headerLabel.textAlignment = TextAlign_Center;
   this.headerLabel.text =
      "<b><font size='+2'>\u2605 SyQon Studio \u2605</font></b><br/>" +
      "<font size='-1'>Neural CLI \u2014 PixInsight Integration</font>";

   this.headerSeparator = new Frame( this );
   this.headerSeparator.frameStyle = FrameStyle_Box;
   this.headerSeparator.setFixedHeight( 2 );

   // ── Image selection ──
   this.imageSelectionLabel = new Label( this );
   this.imageSelectionLabel.text          = "Target Image:";
   this.imageSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.imageSelectionDropdown             = new ComboBox( this );
   this.imageSelectionDropdown.editEnabled = false;

   let windows        = ImageWindow.windows;
   let activeWindowId = getActiveWindowIdSafe();
   for ( let i = 0; i < windows.length; ++i ) {
      let wid = windows[i].mainView.id;
      this.imageSelectionDropdown.addItem( wid );
      this._windowIds.push( wid );
      if ( wid == activeWindowId ) this.imageSelectionDropdown.currentItem = i;
   }

   this.imageSelectionSizer = new HorizontalSizer;
   this.imageSelectionSizer.spacing = 4;
   this.imageSelectionSizer.add( this.imageSelectionLabel );
   this.imageSelectionSizer.add( this.imageSelectionDropdown, 100 );

   // ── Model ──
   this.modelLabel = new Label( this );
   this.modelLabel.text          = "Model:";
   this.modelLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.modelCombo = new ComboBox( this );
   this.modelCombo.editEnabled = false;
   let selModelIdx = 0;
   for ( let i = 0; i < STUDIO_MODELS.length; ++i ) {
      let m = STUDIO_MODELS[i];
      this.modelCombo.addItem( m.label + (m.access == "Included" ? "" : "   \u00B7  Licensed") );
      if ( m.id == P.modelId ) selModelIdx = i;
   }
   this.modelCombo.currentItem = selModelIdx;
   this.modelCombo.onItemSelected = function( index ) {
      P.modelId = STUDIO_MODELS[index].id;
      self.updateModelUI();
   };

   this.modelSizer = new HorizontalSizer;
   this.modelSizer.spacing = 4;
   this.modelSizer.add( this.modelLabel );
   this.modelSizer.add( this.modelCombo, 100 );

   this.contractLabel = new Label( this );
   this.contractLabel.useRichText  = true;
   this.contractLabel.wordWrapping = true;

   // ── Common options ──
   this.domainLabel = new Label( this );
   this.domainLabel.text = "Input Domain:";
   this.domainLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.domainCombo = new ComboBox( this );
   this.domainCombo.addItem( "Auto (read metadata)" );
   this.domainCombo.addItem( "Linear" );
   this.domainCombo.addItem( "Non-linear" );
   this.domainCombo.currentItem = (P.domain == "linear") ? 1 : (P.domain == "nonlinear" ? 2 : 0);
   this.domainCombo.onItemSelected = function( i ) { P.domain = (i == 1) ? "linear" : (i == 2 ? "nonlinear" : "auto"); };
   this.domainSizer = new HorizontalSizer;
   this.domainSizer.spacing = 4;
   this.domainSizer.add( this.domainLabel );
   this.domainSizer.add( this.domainCombo, 100 );

   this.precisionLabel = new Label( this );
   this.precisionLabel.text = "Precision:";
   this.precisionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.precisionLabel.toolTip = "Scientific output sample format. f32 is recommended for the in-PixInsight round-trip.";
   this.precisionCombo = new ComboBox( this );
   this.precisionCombo.addItem( "f32 (recommended)" );
   this.precisionCombo.addItem( "u16" );
   this.precisionCombo.addItem( "f64" );
   this.precisionCombo.currentItem = (P.precision == "u16") ? 1 : (P.precision == "f64" ? 2 : 0);
   this.precisionCombo.onItemSelected = function( i ) { P.precision = (i == 1) ? "u16" : (i == 2 ? "f64" : "f32"); };
   this.precisionSizer = new HorizontalSizer;
   this.precisionSizer.spacing = 4;
   this.precisionSizer.add( this.precisionLabel );
   this.precisionSizer.add( this.precisionCombo, 100 );

   this.tileLabel = new Label( this );
   this.tileLabel.text = "Tile Size:";
   this.tileLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.tileSpin = new SpinBox( this );
   this.tileSpin.minValue = 256; this.tileSpin.maxValue = 2048; this.tileSpin.stepSize = 64;
   this.tileSpin.value = P.tileSize;
   this.tileSpin.onValueUpdated = function( v ) { P.tileSize = v; };
   this.tileSizer = new HorizontalSizer;
   this.tileSizer.spacing = 4;
   this.tileSizer.add( this.tileLabel ); this.tileSizer.add( this.tileSpin ); this.tileSizer.addStretch();

   this.overlapLabel = new Label( this );
   this.overlapLabel.text = "Overlap:";
   this.overlapLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.overlapSpin = new SpinBox( this );
   this.overlapSpin.minValue = 0; this.overlapSpin.maxValue = 512; this.overlapSpin.stepSize = 8;
   this.overlapSpin.value = P.overlap;
   this.overlapSpin.onValueUpdated = function( v ) { P.overlap = v; };
   this.overlapSizer = new HorizontalSizer;
   this.overlapSizer.spacing = 4;
   this.overlapSizer.add( this.overlapLabel ); this.overlapSizer.add( this.overlapSpin ); this.overlapSizer.addStretch();

   this.applicationControl = new NumericControl( this );
   this.applicationControl.label.text = "Application:";
   this.applicationControl.setRange( 0, 1 );
   this.applicationControl.slider.setRange( 0, 100 );
   this.applicationControl.setPrecision( 2 );
   this.applicationControl.setValue( P.application );
   this.applicationControl.toolTip = "Blend the inferred result with the original input (Prism).";
   this.applicationControl.onValueUpdated = function( v ) { P.application = v; };

   // ── Parallax options ──
   this.pxFamilyLabel = new Label( this );
   this.pxFamilyLabel.text = "Family:";
   this.pxFamilyLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.pxFamilyCombo = new ComboBox( this );
   this.pxFamilyCombo.addItem( "Aesthetics" );
   this.pxFamilyCombo.addItem( "Classic" );
   this.pxFamilyCombo.currentItem = (P.parallaxFamily == "classic") ? 1 : 0;
   this.pxFamilyCombo.onItemSelected = function( i ) { P.parallaxFamily = (i == 1) ? "classic" : "aesthetics"; };
   this.pxFamilySizer = new HorizontalSizer;
   this.pxFamilySizer.spacing = 4;
   this.pxFamilySizer.add( this.pxFamilyLabel ); this.pxFamilySizer.add( this.pxFamilyCombo, 100 );

   this.pxCorrectionCheck = new CheckBox( this );
   this.pxCorrectionCheck.text = "Stellar correction / defect repair";
   this.pxCorrectionCheck.checked = P.pxCorrection;
   this.pxCorrectionCheck.onCheck = function( c ) { P.pxCorrection = c; };

   this.pxReductionCheck = new CheckBox( this );
   this.pxReductionCheck.text = "Star reduction";
   this.pxReductionCheck.checked = P.pxReduction;
   this.pxReductionLevelSpin = new SpinBox( this );
   this.pxReductionLevelSpin.minValue = 0; this.pxReductionLevelSpin.maxValue = 10; this.pxReductionLevelSpin.stepSize = 1;
   this.pxReductionLevelSpin.value = P.pxReductionLevel;
   this.pxReductionLevelSpin.enabled = P.pxReduction;
   this.pxReductionLevelSpin.onValueUpdated = function( v ) { P.pxReductionLevel = v; };
   this.pxReductionCheck.onCheck = function( c ) { P.pxReduction = c; self.pxReductionLevelSpin.enabled = c; };
   this.pxReductionLevelLabel = new Label( this );
   this.pxReductionLevelLabel.text = "level:";
   this.pxReductionLevelLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.pxReductionSizer = new HorizontalSizer;
   this.pxReductionSizer.spacing = 4;
   this.pxReductionSizer.add( this.pxReductionCheck );
   this.pxReductionSizer.add( this.pxReductionLevelLabel );
   this.pxReductionSizer.add( this.pxReductionLevelSpin );
   this.pxReductionSizer.addStretch();

   this.pxDeblurCheck = new CheckBox( this );
   this.pxDeblurCheck.text = "Deblur (deconvolution)";
   this.pxDeblurCheck.checked = P.pxDeblur;
   this.pxDeblurStrengthControl = new NumericControl( this );
   this.pxDeblurStrengthControl.label.text = "strength:";
   this.pxDeblurStrengthControl.setRange( 0, 1 );
   this.pxDeblurStrengthControl.slider.setRange( 0, 100 );
   this.pxDeblurStrengthControl.setPrecision( 2 );
   this.pxDeblurStrengthControl.setValue( P.pxDeblurStrength );
   this.pxDeblurStrengthControl.enabled = P.pxDeblur;
   this.pxDeblurStrengthControl.onValueUpdated = function( v ) { P.pxDeblurStrength = v; };
   this.pxDeblurCheck.onCheck = function( c ) { P.pxDeblur = c; self.pxDeblurStrengthControl.enabled = c; };

   // ── Axiom options ──
   this.axStretchLabel = new Label( this );
   this.axStretchLabel.text = "Axiom Stretch:";
   this.axStretchLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.axStretchCombo = new ComboBox( this );
   this.axStretchCombo.addItem( "Auto" );
   this.axStretchCombo.addItem( "Identity (already stretched)" );
   this.axStretchCombo.addItem( "Custom" );
   this.axStretchCombo.currentItem = (P.axiomStretch == "identity") ? 1 : (P.axiomStretch == "custom" ? 2 : 0);
   this.axStretchCombo.onItemSelected = function( i ) {
      P.axiomStretch = (i == 1) ? "identity" : (i == 2 ? "custom" : "auto");
      let custom = (P.axiomStretch == "custom");
      self.axBlackControl.enabled = custom;
      self.axMidControl.enabled   = custom;
      self.axWhiteControl.enabled = custom;
   };
   this.axStretchSizer = new HorizontalSizer;
   this.axStretchSizer.spacing = 4;
   this.axStretchSizer.add( this.axStretchLabel ); this.axStretchSizer.add( this.axStretchCombo, 100 );

   let axCustom = (P.axiomStretch == "custom");
   this.axBlackControl = new NumericControl( this );
   this.axBlackControl.label.text = "black:";
   this.axBlackControl.setRange( 0, 1 ); this.axBlackControl.slider.setRange( 0, 1000 );
   this.axBlackControl.setPrecision( 4 ); this.axBlackControl.setValue( P.axiomBlack );
   this.axBlackControl.enabled = axCustom;
   this.axBlackControl.onValueUpdated = function( v ) { P.axiomBlack = v; };
   this.axMidControl = new NumericControl( this );
   this.axMidControl.label.text = "mid:";
   this.axMidControl.setRange( 0, 1 ); this.axMidControl.slider.setRange( 0, 1000 );
   this.axMidControl.setPrecision( 4 ); this.axMidControl.setValue( P.axiomMid );
   this.axMidControl.enabled = axCustom;
   this.axMidControl.onValueUpdated = function( v ) { P.axiomMid = v; };
   this.axWhiteControl = new NumericControl( this );
   this.axWhiteControl.label.text = "white:";
   this.axWhiteControl.setRange( 0, 1 ); this.axWhiteControl.slider.setRange( 0, 1000 );
   this.axWhiteControl.setPrecision( 4 ); this.axWhiteControl.setValue( P.axiomWhite );
   this.axWhiteControl.enabled = axCustom;
   this.axWhiteControl.onValueUpdated = function( v ) { P.axiomWhite = v; };

   this.axStarsCheck = new CheckBox( this );
   this.axStarsCheck.text = "Also create a Stars-Only image";
   this.axStarsCheck.checked = P.axiomMakeStars;
   this.axStarsCheck.onCheck = function( c ) { P.axiomMakeStars = c; };

   // ── Deep Gradient options ──
   this.dgGradientCheck = new CheckBox( this );
   this.dgGradientCheck.text = "Also create the extracted-gradient image";
   this.dgGradientCheck.checked = P.dgMakeGradient;
   this.dgGradientCheck.onCheck = function( c ) { P.dgMakeGradient = c; };

   // ── Advanced ──
   this.timeoutLabel = new Label( this );
   this.timeoutLabel.text = "Output Timeout (min):";
   this.timeoutLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.timeoutSpin = new SpinBox( this );
   this.timeoutSpin.minValue = 1; this.timeoutSpin.maxValue = 240; this.timeoutSpin.stepSize = 1;
   this.timeoutSpin.value = P.outputTimeoutMinutes;
   this.timeoutSpin.onValueUpdated = function( v ) { P.outputTimeoutMinutes = v; };
   this.timeoutSizer = new HorizontalSizer;
   this.timeoutSizer.spacing = 4;
   this.timeoutSizer.add( this.timeoutLabel ); this.timeoutSizer.add( this.timeoutSpin ); this.timeoutSizer.addStretch();

   this.openDialogCheck = new CheckBox( this );
   this.openDialogCheck.text = "Open dialog when instance is double-clicked or dropped";
   this.openDialogCheck.checked = P.openDialogBox;
   this.openDialogCheck.onCheck = function( c ) { P.openDialogBox = c; };

   // ── Executable ──
   this.setupButton      = new ToolButton( this );
   this.setupButton.icon = this.scaledResource( ":/icons/wrench.png" );
   this.setupButton.setScaledFixedSize( 24, 24 );
   this.setupButton.toolTip = "Locate the syqon-cli executable (inside SyQon Studio).";
   this.setupButton.onClick = function() {
      let ofd = new OpenFileDialog;
      ofd.caption = "Select syqon-cli Executable";
      ofd.multipleSelections = false;
      if ( P.cliPath.length > 0 ) ofd.initialPath = P.cliPath;
      ofd.filters = IS_WINDOWS ? [ ["Executable Files","*.exe"],["All Files","*"] ] : [ ["All Files","*"] ];
      if ( ofd.execute() ) {
         let picked = "";
         if ( ofd.fileName && ofd.fileName.length > 0 ) picked = String( ofd.fileName );
         else if ( ofd.fileNames && ofd.fileNames.length > 0 ) picked = String( ofd.fileNames[0] );
         if ( picked.length > 0 ) {
            picked = resolveBundle( picked );
            P.cliPath = picked; P.save();
            self.exePathLabel.text = picked;
            self.cliStatusLabel.text = validateCli( picked )
               ? "<font color='#2ecc71'>\u2714 syqon-cli validated.</font>"
               : "<font color='#e74c3c'>\u2716 Could not validate (\u2013\u2013version failed).</font>";
         }
      }
   };

   this.exePathLabel = new TextBox( this );
   this.exePathLabel.readOnly = true;
   this.exePathLabel.setFixedHeight( 44 );
   this.exePathLabel.text = P.cliPath.length > 0 ? P.cliPath : "No syqon-cli executable selected.";

   this.exePathSizer = new HorizontalSizer;
   this.exePathSizer.spacing = 6;
   this.exePathSizer.add( this.setupButton );
   this.exePathSizer.add( this.exePathLabel, 100 );

   this.cliStatusLabel = new Label( this );
   this.cliStatusLabel.useRichText = true;
   this.cliStatusLabel.text = (P.cliPath.length > 0 && validateCli( P.cliPath ))
      ? "<font color='#2ecc71'>\u2714 syqon-cli validated.</font>"
      : "<i>Sign in through SyQon Studio, then locate syqon-cli if it isn't auto-detected.</i>";

   // ── Buttons ──
   this.okButton      = new PushButton( this );
   this.okButton.text = "OK";
   this.okButton.onClick = function() { self.syncToParameters(); self.ok(); };

   this.cancelButton      = new PushButton( this );
   this.cancelButton.text = "Cancel";
   this.cancelButton.onClick = function() { self.cancel(); };

   this.newInstanceButton = new ToolButton( this );
   this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
   this.newInstanceButton.setScaledFixedSize( 24, 24 );
   this.newInstanceButton.toolTip = "Drag to workspace to create a new process instance";
   this.newInstanceButton.onMousePress = function() { self.syncToParameters(); self.newInstance(); };

   this.buttonsSizer = new HorizontalSizer;
   this.buttonsSizer.spacing = 6;
   this.buttonsSizer.add( this.newInstanceButton );
   this.buttonsSizer.addStretch();
   this.buttonsSizer.add( this.okButton );
   this.buttonsSizer.add( this.cancelButton );

   // ── Label width alignment ──
   let labelWidth = this.font.width( "Output Timeout (min):MMMM" );
   let labelsToAlign = [ this.imageSelectionLabel, this.modelLabel, this.domainLabel, this.precisionLabel,
                         this.tileLabel, this.overlapLabel, this.pxFamilyLabel, this.axStretchLabel,
                         this.timeoutLabel ];
   for ( let i = 0; i < labelsToAlign.length; ++i )
      labelsToAlign[i].setFixedWidth( labelWidth );

   // ── GroupBoxes ──
   function makeGroup( title, items ) {
      let gb = new GroupBox( self );
      gb.title = title;
      gb.sizer = new VerticalSizer;
      gb.sizer.margin = 6;
      gb.sizer.spacing = 4;
      for ( let i = 0; i < items.length; ++i ) gb.sizer.add( items[i] );
      return gb;
   }

   this.imageGroup  = makeGroup( "Target Image", [ this.imageSelectionSizer ] );
   this.modelGroup  = makeGroup( "Neural Model", [ this.modelSizer, this.contractLabel ] );
   this.commonGroup = makeGroup( "Common Options",
      [ this.domainSizer, this.precisionSizer, this.tileSizer, this.overlapSizer, this.applicationControl ] );
   this.parallaxGroup = makeGroup( "Parallax Options",
      [ this.pxFamilySizer, this.pxCorrectionCheck, this.pxReductionSizer, this.pxDeblurCheck, this.pxDeblurStrengthControl ] );
   this.axiomGroup = makeGroup( "Axiom Options",
      [ this.axStretchSizer, this.axBlackControl, this.axMidControl, this.axWhiteControl, this.axStarsCheck ] );
   this.gradientGroup = makeGroup( "Deep Gradient Options", [ this.dgGradientCheck ] );
   this.advancedGroup = makeGroup( "Advanced", [ this.timeoutSizer, this.openDialogCheck ] );

   this.executableGroup = new GroupBox( this );
   this.executableGroup.title = "SyQon Studio CLI (syqon-cli)";
   this.executableGroup.sizer = new VerticalSizer;
   this.executableGroup.sizer.margin = 6;
   this.executableGroup.sizer.spacing = 4;
   this.executableGroup.sizer.add( this.exePathSizer );
   this.executableGroup.sizer.add( this.cliStatusLabel );

   this.copyrightLabel = new Label( this );
   this.copyrightLabel.useRichText = true;
   this.copyrightLabel.textAlignment = TextAlign_Center;
   this.copyrightLabel.text =
      "<font size='-1'>\u00A9 SyQon 2026 \u2014 www.syqon.eu &nbsp;\u2014&nbsp; " +
      "Script by Franklin Marek \u2014 www.setiastro.com</font>";

   // ── Main sizer ──
   this.sizer = new VerticalSizer;
   this.sizer.margin = 12;
   this.sizer.spacing = 8;
   this.sizer.add( this.headerLabel );
   this.sizer.add( this.headerSeparator );
   this.sizer.addSpacing( 4 );
   this.sizer.add( this.imageGroup );
   this.sizer.add( this.modelGroup );
   this.sizer.add( this.commonGroup );
   this.sizer.add( this.parallaxGroup );
   this.sizer.add( this.axiomGroup );
   this.sizer.add( this.gradientGroup );
   this.sizer.add( this.executableGroup );
   this.sizer.add( this.advancedGroup );
   this.sizer.addSpacing( 8 );
   this.sizer.add( this.buttonsSizer );
   this.sizer.addSpacing( 2 );
   this.sizer.add( this.copyrightLabel );

   this.windowTitle = "SyQon Studio " + VERSION;
   this.setMinWidth( 580 );

   this.updateModelUI();
   this.adjustToContents();

   if ( P.targetViewId && P.targetViewId.length > 0 )
      this.selectViewById( P.targetViewId );
}

SyQonStudioDialog.prototype = new Dialog;

// ----------------------------------------------------------------------------
// Main
// ----------------------------------------------------------------------------

function main() {
   console.show();
   console.noteln( "SyQon \u2605 S T U D I O \u2605  " + VERSION );
   console.noteln( "\u00A9 SyQon 2026 \u2014 www.syqon.eu" );
   console.noteln( "Script by Franklin Marek \u2014 www.setiastro.com" );
   console.flush();

   P.load();

   if ( Parameters.isGlobalTarget ) {
      console.criticalln( "This script cannot run in a global context." );
      return;
   }

   if ( Parameters.isViewTarget && Parameters.targetView ) {
      P.targetView   = Parameters.targetView;
      P.targetViewId = Parameters.targetView.id;
      P.save();

      if ( P.openDialogBox ) {
         let dlg = new SyQonStudioDialog();
         dlg.selectViewById( P.targetViewId );
         if ( dlg.execute() ) {
            let selectedWindow = getSelectedWindowFromDialog( dlg )
               || resolveWindowFromViewId( P.targetViewId );
            executeStudioOnWindow( selectedWindow );
         } else {
            console.noteln( "SyQon Studio dialog closed." );
         }
         return;
      }

      executeStudioOnWindow( Parameters.targetView.window );
      return;
   }

   let dlg = new SyQonStudioDialog();
   if ( dlg.execute() ) {
      let selectedWindow = getSelectedWindowFromDialog( dlg );
      if ( !selectedWindow && P.targetViewId.length > 0 )
         selectedWindow = resolveWindowFromViewId( P.targetViewId );
      if ( !selectedWindow )
         throw new Error( "Please select an image." );
      executeStudioOnWindow( selectedWindow );
   } else {
      console.noteln( "SyQon Studio dialog closed." );
   }
}

main();
